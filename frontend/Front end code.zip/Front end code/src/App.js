import "./App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";

import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Search from "./pages/Search";
import RulingDetail from "./pages/RulingDetail";
import QAGenerator from "./pages/QAGenerator";
import Insights from "./pages/Insights";
import Login from "./Login";  // ✅ ADD THIS

// ✅ PROTECTED ROUTE COMPONENT
function PrivateRoute({ children }) {
  const isLoggedIn = localStorage.getItem("loggedIn") === "true";
  return isLoggedIn ? children : <Navigate to="/login" replace />;
}

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>

          {/* ✅ LOGIN ROUTE */}
          <Route path="/login" element={<Login />} />

          {/* ✅ ALL PROTECTED ROUTES */}
          <Route
            path="/"
            element={
              <PrivateRoute>
                <Layout />
              </PrivateRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="search" element={<Search />} />
            <Route path="ruling/:id" element={<RulingDetail />} />
            <Route path="qa-generator" element={<QAGenerator />} />
            <Route path="insights" element={<Insights />} />
          </Route>

          {/* ✅ IF USER ENTERS INVALID ROUTE */}
          <Route path="*" element={<Navigate to="/" />} />

        </Routes>
      </BrowserRouter>

      <Toaster position="top-right" richColors />
    </div>
  );
}

export default App;