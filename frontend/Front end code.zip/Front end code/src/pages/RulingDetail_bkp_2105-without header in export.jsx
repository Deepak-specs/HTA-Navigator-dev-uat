// RulingDetail_PdfWorking.jsx

import { useState, useEffect, useMemo, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Skeleton } from "../components/ui/skeleton";
import { Separator } from "../components/ui/separator";
import jsPDF from "jspdf"; 
import html2canvas from "html2canvas";
import {  
  ArrowLeft,  
  Download,  
  BrainCircuit,  
  Calendar,
  Building2,
  CheckCircle,
  XCircle,
  AlertCircle,
  Loader2,
  Copy,
  FileText
} from "lucide-react";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

// Dev-only Axios logging interceptors (deduplicated)
if (process.env.NODE_ENV === "development" && !axios.__LOG_INTERCEPTORS__) {
  axios.__LOG_INTERCEPTORS__ = true;
  axios.interceptors.request.use(cfg => {
    // eslint-disable-next-line no-console
    console.log("[REQ]", cfg.method?.toUpperCase(), cfg.url, { headers: cfg.headers, params: cfg.params });
    return cfg;
  });
  axios.interceptors.response.use(
    res => {
      // eslint-disable-next-line no-console
      console.log("[RES]", res.status, res.config?.url, res.data);
      return res;
    },
    err => {
      // eslint-disable-next-line no-console
      console.error("[ERR]", {
        message: err.message,
        code: err.code,
        url: err.config?.url,
        method: err.config?.method,
        status: err.response?.status,
        data: err.response?.data,
      });
      return Promise.reject(err);
    }
  );
}

const getOutcomeBadgeClass = (outcome) => {
  if (outcome === "Positive") return "badge-positive";
  if (outcome === "Negative") return "badge-negative";
  if (outcome?.includes?.("Conditions")) return "badge-conditional";
  return "bg-slate-100 text-slate-700 border-slate-200";
};

const getOutcomeIcon = (outcome) => {
  if (outcome === "Positive") return <CheckCircle className="w-5 h-5 text-emerald-600" />;
  if (outcome === "Negative") return <XCircle className="w-5 h-5 text-red-600" />;
  return <AlertCircle className="w-5 h-5 text-amber-600" />;
};

// Simple warning de-duplication
const seenWarnings = new Set();
function warnOnce(key, payload) {
  if (!seenWarnings.has(key)) {
    // eslint-disable-next-line no-console
    console.warn(key, payload);
    seenWarnings.add(key);
  }
}

export default function RulingDetail() {
  const { id } = useParams();
  const [ruling, setRuling] = useState(null);
  const [loading, setLoading] = useState(true);
  const [aiSummary, setAiSummary] = useState(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const exportRef = useRef(null);

  // Expected ruling fields for quick validation
  const requiredRulingFields = useMemo(
    () => [
      "id",
      "title",
      "drug_name",
      "manufacturer",
      "indication",
      "comparator",
      "price_per_unit",
      "annual_cost",
      "patient_population",
      "clinical_evidence",
      "cost_effectiveness",
      "budget_impact",
      "full_text",
      "decision_outcome",
      "therapy_area",
      "dossier_category",
      "decision_type",
      "decision_date",
      "zin_reference",
      "summary",
      "key_considerations",
      "tags"
    ],
    []
  );

  useEffect(() => {
    // Sanity logs for API base
    // eslint-disable-next-line no-console
    console.log("REACT_APP_BACKEND_URL:", process.env.REACT_APP_BACKEND_URL);
    console.log("API base:", API);

    const fetchRuling = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`${API}/rulings/${id}`);
        const data = response?.data;

        if (!data || typeof data !== "object") {
          warnOnce("Expected single ruling object, got:", data);
          setRuling(null);
          toast.error("Ruling response format is invalid");
        } else {
          // Validate presence of key fields and shapes
          requiredRulingFields.forEach((f) => {
            if (data?.[f] == null) {
              warnOnce(`ruling missing field: ${f}`, data);
            }
          });
          if (!Array.isArray(data?.key_considerations)) {
            warnOnce("ruling.key_considerations should be an array", data?.key_considerations);
          }
          if (!Array.isArray(data?.tags)) {
            warnOnce("ruling.tags should be an array", data?.tags);
          }
          setRuling(data);
        }
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error("Failed to fetch ruling:", {
          message: error?.message,
          code: error?.code,
          url: error?.config?.url,
          status: error?.response?.status,
          data: error?.response?.data
        });
        toast.error("Failed to load ruling details");
        setRuling(null);
      } finally {
        setLoading(false);
      }
    };

    if (id) fetchRuling();
  }, [id, requiredRulingFields]);

  const generateSummary = async () => {
    setSummaryLoading(true);
    try {
      const response = await axios.post(`${API}/rulings/${id}/summarize`);
      const data = response?.data;
      if (!data || typeof data !== "object") {
        warnOnce("AI summary response should be an object", data);
        toast.error("Invalid AI summary response");
      } else {
        // light checks
        if (data?.ai_summary == null) warnOnce("aiSummary missing field: ai_summary", data);
        if (!Array.isArray(data?.key_points)) warnOnce("aiSummary.key_points should be an array", data?.key_points);
        if (data?.generated_at == null) warnOnce("aiSummary missing field: generated_at", data);
        setAiSummary(data);
        toast.success("AI summary generated successfully");
      }
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error("Failed to generate summary:", {
        message: error?.message,
        code: error?.code,
        url: error?.config?.url,
        status: error?.response?.status,
        data: error?.response?.data
      });
      toast.error("Failed to generate AI summary");
    } finally {
      setSummaryLoading(false);
    }
  };

  const copyToClipboard = (text) => {
    const safeText = text ?? "";
    navigator.clipboard.writeText(safeText);
    toast.success("Copied to clipboard");
  };

  // Export the visible detail area as PDF 
  const exportToPdf = async () => { 
    const node = exportRef.current; 
    if (!node) { toast.error("Nothing to export"); 
      return; 
    } try 
    { // Ensure white background so dark theme doesn’t bleed into PDF 
    const originalBg = node.style.backgroundColor; 
    node.style.backgroundColor = "#ffffff";

// Render with html2canvas
  const canvas = await html2canvas(node, {
    scale: 2, // sharper text
    useCORS: true,
    backgroundColor: "#ffffff",
    logging: process.env.NODE_ENV === "development"
  });

  // Restore background
  node.style.backgroundColor = originalBg || "";

  const imgData = canvas.toDataURL("image/png");
  const pdf = new jsPDF("p", "mm", "a4");
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  // Dimensions in px from canvas
  const imgWidthPx = canvas.width;
  const imgHeightPx = canvas.height;

  // Convert px to mm: 1 px at 96 DPI = 25.4/96 mm
  const pxToMm = (px) => (px * 25.4) / 96;

  // Compute image size in mm preserving aspect ratio to fit page width with margins
  const margin = 10; // mm
  const availableWidth = pageWidth - margin * 2;
  const imgWidthMm = availableWidth;
  const imgHeightMm = (imgHeightPx / imgWidthPx) * imgWidthMm;

  // If the content height exceeds one page, slice across multiple pages
  let remainingHeightMm = imgHeightMm;
  let positionY = margin;

  // Add first page
  pdf.addImage(imgData, "PNG", margin, positionY, imgWidthMm, Math.min(remainingHeightMm, pageHeight - margin * 2), undefined, "FAST");
  remainingHeightMm -= (pageHeight - margin * 2);

  // For additional pages, we need to draw slices.
  // jsPDF doesn’t natively support slicing; we emulate by drawing the full image and shifting it via page canvas transform.
  // Simpler approach: create multiple canvases by cropping portions. For performance, we will use internal addImage with a loop using aliasing via startY offset.

  // Fallback multi-page approach: scale the full image and add chunks by translating the y start via a canvas cropping helper.
  if (remainingHeightMm > 0) {
    // Create an offscreen canvas we can reuse for page slices
    const sliceCanvas = document.createElement("canvas");
    const ctx = sliceCanvas.getContext("2d");

    // Target width in px based on availableWidth mm converted back to px using 96 DPI
    const mmToPx = (mm) => (mm * 96) / 25.4;
    const targetWidthPx = Math.floor(mmToPx(availableWidth));
    const targetPageHeightPx = Math.floor(mmToPx(pageHeight - margin * 2));

    // Scale factor from original canvas width to target width
    const scaleX = targetWidthPx / imgWidthPx;

    let offsetPx = Math.floor(mmToPx(pageHeight - margin * 2) / (imgWidthMm / imgWidthPx)); // initial consumed height in px

    while (offsetPx < imgHeightPx) {
      // Determine the slice height in original px that maps to the target page height
      const sliceHeightPx = Math.min(imgHeightPx - offsetPx, Math.floor(targetPageHeightPx / scaleX));

      // Resize slice canvas to target width/height
      sliceCanvas.width = targetWidthPx;
      sliceCanvas.height = Math.floor(sliceHeightPx * scaleX);

      // Draw the slice
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, sliceCanvas.width, sliceCanvas.height);
      ctx.drawImage(
        canvas,
        0, offsetPx,                      // source x,y in original
        imgWidthPx, sliceHeightPx,        // source w,h
        0, 0,                              // dest x,y
        sliceCanvas.width, sliceCanvas.height // dest w,h
      );

      const sliceImg = sliceCanvas.toDataURL("image/png");

      pdf.addPage();
      pdf.addImage(sliceImg, "PNG", margin, margin, availableWidth, pageHeight - margin * 2, undefined, "FAST");

      offsetPx += sliceHeightPx;
    }
  }

  const safeTitle = (ruling?.title || "ruling").replace(/[^\w\-]+/g, "_").slice(0, 60);
  const filename = `${safeTitle}_${ruling?.id || "export"}.pdf`;

  pdf.save(filename);
  toast.success("PDF exported");
  } catch (e) {
    // eslint-disable-next-line no-console
    console.error("PDF export failed:", e);
    toast.error("Failed to export PDF");
  }
};


  if (loading) {
    return (
      <div className="p-8" data-testid="ruling-detail-loading">
        <Skeleton className="h-8 w-32 mb-8" />
        <div className="grid grid-cols-3 gap-8">
          <div className="col-span-2 space-y-6">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-96 w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!ruling) {
    return (
      <div className="p-8 text-center" data-testid="ruling-not-found">
        <FileText className="w-16 h-16 text-slate-300 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-slate-900 mb-2">Ruling Not Found</h2>
        <p className="text-slate-500 mb-4">The requested ruling could not be found.</p>
        <Link to="/search">
          <Button>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Search
          </Button>
        </Link>
      </div>
    );
  }

  // Null-safe field extractions with sensible fallbacks
  const outcome = ruling?.decision_outcome ?? "Unknown";
  const therapyArea = ruling?.therapy_area ?? "Unknown area";
  const decisionType = ruling?.decision_type ?? "Unknown type";
  const decisionDate = ruling?.decision_date ?? "Unknown date";
  const dossierCategory = ruling?.dossier_category ?? "Unknown date";
  const zinRef = ruling?.zin_reference ?? "N/A";
  const title = ruling?.title ?? "Untitled ruling";
  const summary = ruling?.summary ?? "No summary available.";
  const drugName = ruling?.drug_name ?? "Unknown drug";
  const manufacturer = ruling?.manufacturer ?? "Unknown manufacturer";
  const indication = ruling?.indication ?? "N/A";
  const comparator = ruling?.comparator ?? "N/A";
  const pricePerUnit = ruling?.price_per_unit ?? "N/A";
  const annualCost = ruling?.annual_cost ?? "N/A";
  const patientPopulation = ruling?.patient_population ?? "N/A";
  const clinicalEvidence = ruling?.clinical_evidence ?? "Not provided.";
  const costEffectiveness = ruling?.cost_effectiveness ?? "Not provided.";
  const budgetImpact = ruling?.budget_impact ?? "Not provided.";
  const fullText = ruling?.full_text ?? "";
  const keyConsiderations = Array.isArray(ruling?.key_considerations) ? ruling.key_considerations : [];
  const tags = Array.isArray(ruling?.tags) ? ruling.tags : [];

  return (
    <div data-testid="ruling-detail-page">
      {/* Header */}
      <header className="page-header">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/search">
              <Button variant="ghost" size="icon" data-testid="back-btn">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-mono text-slate-400 bg-slate-100 px-2 py-1 rounded">
                  {ruling?.id ?? "N/A"}
                </span>
                <Badge className={getOutcomeBadgeClass(outcome)}>
                  {outcome}
                </Badge>
              </div>
              <h1 className="text-xl font-bold text-slate-900 font-heading mt-2">
                {title}
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" data-testid="download-btn" onClick={exportToPdf} title="Export the details section as PDF" >
              <Download className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </div>
      </header>


      {/* Content */}
      <div className="p-8">
        <div className="detail-layout bg-white"
        ref={exportRef}
        >
          {/* Main Content */}
          <div className="space-y-6">
            {/* Drug Info Card */}
            <Card className="border-slate-200" data-testid="drug-info-card">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                  Drug Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Drug Name</p>
                    <p className="text-lg font-semibold text-sky-600">{drugName}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Manufacturer</p>
                    <p className="text-slate-900 font-medium flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      {manufacturer}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Indication</p>
                    <p className="text-slate-700">{indication}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Comparator</p>
                    <p className="text-slate-700">{comparator}</p>
                  </div>
                </div>

                <Separator className="my-6" />

                <div className="grid grid-cols-3 gap-6">
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Price per Unit</p>
                    <p className="text-slate-900 font-mono">{pricePerUnit}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Annual Cost</p>
                    <p className="text-slate-900 font-mono">{annualCost}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Patient Population</p>
                    <p className="text-slate-700 text-sm">{patientPopulation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Assessment Details */}
            <Card className="border-slate-200" data-testid="assessment-details">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                  Assessment Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Clinical Evidence</p>
                  <p className="text-slate-700 leading-relaxed">{clinicalEvidence}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Cost-Effectiveness</p>
                  <p className="text-slate-700 leading-relaxed">{costEffectiveness}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Budget Impact</p>
                  <p className="text-slate-700 leading-relaxed">{budgetImpact}</p>
                </div>
              </CardContent>
            </Card>

            {/* Full Assessment Text */}
            <Card className="border-slate-200" data-testid="full-assessment">
              <CardHeader className="pb-4 flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                  Full Assessment Report
                </CardTitle>
                <Button  
                  variant="ghost"  
                  size="sm"
                  onClick={() => copyToClipboard(fullText)}
                  data-testid="copy-report-btn"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              </CardHeader>
              <CardContent>
                <div className="bg-slate-50 rounded-lg p-6 font-mono text-sm text-slate-700 whitespace-pre-wrap leading-relaxed max-h-96 overflow-y-auto">
                  {fullText || "No full text available."}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Decision Summary */}
            <Card className="border-slate-200 sticky top-24" data-testid="decision-summary">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3">
                  {getOutcomeIcon(outcome)}
                  <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                    Decision Summary
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">Therapy Area</span>
                  <Badge variant="outline">{therapyArea}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">Dossier Category</span>
                  {/* <Badge variant="outline">{dossierCategory}</Badge> */}
                  <span className="text-sm font-medium">{dossierCategory}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">Decision Type</span>
                  <span className="text-sm font-medium">{decisionType}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">Decision Date</span>
                  <span className="text-sm font-mono flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {decisionDate}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500">ZIN Reference</span>
                  <span className="text-sm font-mono">{zinRef}</span>
                </div>

                <Separator />

                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Official Summary</p>
                  <p className="text-sm text-slate-700 leading-relaxed">{summary}</p>
                </div>

                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Key Considerations</p>
                  {keyConsiderations.length > 0 ? (
                    <ul className="space-y-2">
                      {keyConsiderations.map((consideration, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-slate-700">
                          <CheckCircle className="w-4 h-4 text-sky-500 mt-0.5 flex-shrink-0" />
                          <span>{consideration}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-slate-500">No key considerations provided.</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* AI Summary Card */}
            {/* <Card className="ai-summary-card" data-testid="ai-summary-card">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-2">
                  <BrainCircuit className="w-5 h-5 text-sky-600" />
                  <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                    AI-Powered Summary
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {aiSummary ? (
                  <div className="space-y-4 animate-fade-in-up">
                    <p className="text-slate-700 leading-relaxed">{aiSummary?.ai_summary ?? "No AI summary text."}</p>
                    <Separator />
                    <div>
                      <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Key Points</p>
                      {Array.isArray(aiSummary?.key_points) && aiSummary.key_points.length > 0 ? (
                        <ul className="space-y-2">
                          {aiSummary.key_points.map((point, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-slate-700">
                              <span className="w-5 h-5 bg-sky-100 text-sky-600 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0">
                                {idx + 1}
                              </span>
                              <span>{point}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-slate-500">No key points provided.</p>
                      )}
                    </div>
                    <p className="text-xs text-slate-400">
                      Generated: {aiSummary?.generated_at ? new Date(aiSummary.generated_at).toLocaleString() : "Unknown time"}
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-sm text-slate-500 mb-4">
                      Get an AI-generated executive summary and key insights from this ruling.
                    </p>
                    <Button  
                      onClick={generateSummary}  
                      disabled={summaryLoading}
                      className="w-full bg-sky-600 hover:bg-sky-700"
                      data-testid="generate-summary-btn"
                    >
                      {summaryLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <BrainCircuit className="w-4 h-4 mr-2" />
                          Generate AI Summary
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card> */}

            {/* Tags */}
            <Card className="border-slate-200" data-testid="tags-card">
              <CardHeader className="pb-4">
                <CardTitle className="text-sm font-semibold text-slate-900">Tags</CardTitle>
              </CardHeader>
              <CardContent>
                {tags.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {tags.map(tag => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-slate-500">No tags provided.</p>
                )}
              </CardContent>
            </Card>

            <div className="text-center py-4">
              <p className="text-sm text-slate-500 mb-4">
                AI-Powered Summary
              </p>
            </div>


          </div>
        </div>
      </div>
    </div>
  );
}