import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import ReactMarkdown from "react-markdown";
import { Card, CardContent } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Checkbox } from "../components/ui/checkbox";
import { Label } from "../components/ui/label";
import { Skeleton } from "../components/ui/skeleton";
import {
  Search as SearchIcon,
  Filter,
  ChevronRight,
  ChevronLeft,
  Calendar,
  Building2,
  X,
  FileText,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;
const PAGE_SIZE = 15;

// Dev-only Axios logging interceptors (avoid double install)
if (process.env.NODE_ENV === "development" && !axios.__LOG_INTERCEPTORS__) {
  axios.__LOG_INTERCEPTORS__ = true;
  axios.interceptors.request.use((cfg) => {
    console.log("[REQ]", cfg.method?.toUpperCase(), cfg.url, {
      headers: cfg.headers,
      params: cfg.params,
    });
    return cfg;
  });
  axios.interceptors.response.use(
    (res) => {
      console.log("[RES]", res.status, res.config?.url, res.data);
      return res;
    },
    (err) => {
      console.error("[ERR]", {
        message: err.message,
        code: err.code,
        url: err.config?.url,
        method: err.config?.method,
        status: err.response?.status,
        data: err.response?.data,
      });
      return Promise.reject(err);
    }
  );
}

// Outcome badge helper
const getOutcomeBadgeClass = (outcome) => {
  if (outcome === "Positive") return "badge-positive";
  if (outcome === "Negative") return "badge-negative";
  if (outcome?.includes?.("Conditions")) return "badge-conditional";
  return "bg-slate-100 text-slate-700 border-slate-200";
};

// Simple warning de-duplication
const seenWarnings = new Set();
function warnOnce(key, payload) {
  if (!seenWarnings.has(key)) {
    console.warn(key, payload);
    seenWarnings.add(key);
  }
}

// Reusable inline SVG spinner
function Spinner({ className = "w-4 h-4" }) {
  return (
    <svg
      className={`animate-spin ${className}`}
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
      />
    </svg>
  );
}

// ── Result Box with Markdown + Cited Sources ───────────────────────────────────
function ResultBox({ answer, sources, placeholder, "data-testid": testId }) {
  const isEmpty = !answer || answer.trim() === "";

  if (isEmpty) {
    return (
      <div
        data-testid={testId}
        className="
          w-full min-h-[42px] px-4 py-2.5
          rounded-md border border-input bg-slate-50
          text-sm leading-relaxed text-slate-400
        "
      >
        {placeholder}
      </div>
    );
  }

  return (
    <div
      data-testid={testId}
      className="
        w-full px-4 py-3
        rounded-md bg-slate-50
        text-sm leading-relaxed text-slate-800
        transition-all duration-300 ease-in-out
      "
      style={{ border: "2px solid #0f172a" }}
    >
      {/* ✅ Renders markdown properly */}
      <div className="prose prose-sm max-w-none prose-slate">
        <ReactMarkdown>{answer}</ReactMarkdown>
      </div>

      {/* ✅ Cited Sources — (1) (2) (3) as clickable hyperlinks */}
      {sources && sources.length > 0 && (
        <div className="flex items-center flex-wrap gap-2 mt-3 pt-3 border-t border-slate-200">
          <span className="text-xs font-semibold text-slate-500">
            Cited &mdash; Sources
          </span>
          {sources.map((src, idx) => (
            <a
              key={idx}
              href={src.url}
              target="_blank"
              rel="noopener noreferrer"
              title={`📄 ${src.file} — Page ${src.page_number ?? "?"}`}
              className="
                inline-flex items-center justify-center
                w-6 h-6 rounded
                bg-sky-600 hover:bg-sky-700
                text-white text-xs font-bold
                transition-colors duration-150
                no-underline
              "
            >
              {idx + 1}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Pagination Controls Component ─────────────────────────────────────────────
function PaginationControls({ currentPage, totalPages, onPageChange }) {
  if (totalPages <= 1) return null;

  const getPageNumbers = () => {
    const pages = new Set();
    pages.add(1);
    pages.add(totalPages);
    for (
      let i = Math.max(1, currentPage - 2);
      i <= Math.min(totalPages, currentPage + 2);
      i++
    ) {
      pages.add(i);
    }
    const sorted = [...pages].sort((a, b) => a - b);
    const result = [];
    for (let i = 0; i < sorted.length; i++) {
      if (i > 0 && sorted[i] - sorted[i - 1] > 1) result.push("...");
      result.push(sorted[i]);
    }
    return result;
  };

  return (
    <div
      className="flex items-center justify-between mt-8 pt-6 border-t border-slate-200"
      data-testid="pagination-controls"
    >
      <p className="text-sm text-slate-500">
        Page{" "}
        <span className="font-semibold text-slate-700">{currentPage}</span> of{" "}
        <span className="font-semibold text-slate-700">{totalPages}</span>
      </p>

      <div className="flex items-center gap-1">
        <Button
          variant="outline" size="sm"
          onClick={() => onPageChange(1)}
          disabled={currentPage === 1}
          data-testid="pagination-first"
          className="h-8 w-8 p-0" title="First page"
        >
          <ChevronsLeft className="w-4 h-4" />
        </Button>

        <Button
          variant="outline" size="sm"
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          data-testid="pagination-prev"
          className="h-8 w-8 p-0" title="Previous page"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>

        {getPageNumbers().map((page, idx) =>
          page === "..." ? (
            <span
              key={`ellipsis-${idx}`}
              className="h-8 w-8 flex items-center justify-center text-sm text-slate-400"
            >
              …
            </span>
          ) : (
            <Button
              key={page}
              variant={currentPage === page ? "default" : "outline"}
              size="sm"
              onClick={() => onPageChange(page)}
              data-testid={`pagination-page-${page}`}
              className={`h-8 w-8 p-0 text-sm ${
                currentPage === page
                  ? "bg-sky-600 hover:bg-sky-700 text-white border-sky-600"
                  : ""
              }`}
            >
              {page}
            </Button>
          )
        )}

        <Button
          variant="outline" size="sm"
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          data-testid="pagination-next"
          className="h-8 w-8 p-0" title="Next page"
        >
          <ChevronRight className="w-4 h-4" />
        </Button>

        <Button
          variant="outline" size="sm"
          onClick={() => onPageChange(totalPages)}
          disabled={currentPage === totalPages}
          data-testid="pagination-last"
          className="h-8 w-8 p-0" title="Last page"
        >
          <ChevronsRight className="w-4 h-4" />
        </Button>
      </div>

      <div className="flex items-center gap-2 text-sm text-slate-500">
        <span>Go to</span>
        <Input
          type="number"
          min={1}
          max={totalPages}
          defaultValue={currentPage}
          key={currentPage}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              const val = parseInt(e.target.value, 10);
              if (!isNaN(val) && val >= 1 && val <= totalPages)
                onPageChange(val);
            }
          }}
          className="h-8 w-16 text-center text-sm"
          data-testid="pagination-jump-input"
        />
      </div>
    </div>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────
export default function Search() {
  const [rulings, setRulings]                                       = useState([]);
  const [filteredRulings, setFilteredRulings]                       = useState([]);
  const [loading, setLoading]                                       = useState(true);
  const [isSearching, setIsSearching]                               = useState(false);
  const [searchQuery, setSearchQuery]                               = useState("");
  const [therapyAreas, setTherapyAreas]                             = useState([]);
  const [decisionOutcomes, setDecisionOutcomes]                     = useState([]);
  const [selectedTherapyAreas, setSelectedTherapyAreas]             = useState([]);
  const [selectedOutcomes, setSelectedOutcomes]                     = useState([]);
  const [dossierCategories, setDossierCategories]                   = useState([]);
  const [selectedDossierCategories, setSelectedDossierCategories]   = useState([]);
  const [fetchError, setFetchError]                                 = useState(null);
  const [currentPage, setCurrentPage]                               = useState(1);
  const [backendAnswer, setBackendAnswer]                           = useState("");
  const [backendSources, setBackendSources]                         = useState([]);

  // ── YEAR FILTER: state ─────────────────────────────────────────────────────
  const [selectedYears, setSelectedYears] = useState([]);
  // ── YEAR FILTER end ────────────────────────────────────────────────────────

  const requiredRulingFields = useMemo(
    () => [
      "id", "title", "summary", "decision_outcome",
      "therapy_area", "dossier_category", "manufacturer",
      "decision_date", "drug_name", "tags",
    ],
    []
  );

  // ── YEAR FILTER: helper — true when ruling has no valid date ───────────────
  const isUnknownDate = (ruling) => {
    const date = ruling?.decision_date || "";
    return !date || date.length < 4 || !/^\d{4}$/.test(date.substring(0, 4));
  };

  // ── YEAR FILTER: sorted unique years derived from loaded rulings ───────────
  const availableYears = useMemo(() => {
    const yearSet = new Set();
    rulings.forEach((r) => {
      const date = r?.decision_date || "";
      if (date && date.length >= 4) {
        const year = date.substring(0, 4);
        if (/^\d{4}$/.test(year)) yearSet.add(year);
      }
    });
    return [...yearSet].sort((a, b) => b.localeCompare(a)); // descending
  }, [rulings]);

  // ── YEAR FILTER: true when at least one ruling has a missing/invalid date ──
  const hasUnknownDateRulings = useMemo(
    () => rulings.some((r) => isUnknownDate(r)),
    [rulings]
  );
  // ── YEAR FILTER end ────────────────────────────────────────────────────────

  // ── Derived pagination values ───────────────────────────────────────────────
  const totalPages = Math.max(1, Math.ceil(filteredRulings.length / PAGE_SIZE));

  const paginatedRulings = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredRulings.slice(start, start + PAGE_SIZE);
  }, [filteredRulings, currentPage]);

  const resetPage = () => setCurrentPage(1);

  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // ── Initial data fetch ──────────────────────────────────────────────────────
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setFetchError(null);
      try {
        const [r, ta, doRes, dc] = await Promise.all([
          axios.get(`${API}/rulings`),
          axios.get(`${API}/therapy-areas`),
          axios.get(`${API}/decision-outcomes`),
          axios.get(`${API}/dossier-categories`),
        ]);

        const rulingsData = r.data || [];
        rulingsData.slice(0, 5).forEach((item, idx) => {
          requiredRulingFields.forEach((f) => {
            if (item?.[f] == null)
              warnOnce(`rulings[${idx}] missing field: ${f}`, item);
          });
          if (!Array.isArray(item?.tags))
            warnOnce(`rulings[${idx}].tags should be an array`, item?.tags);
        });

        setRulings(rulingsData);
        setFilteredRulings(rulingsData);
        setTherapyAreas(ta.data || []);
        setDecisionOutcomes(doRes.data || []);
        setDossierCategories(dc.data || []);
      } catch (e) {
        console.error(e);
        setFetchError("Failed to load data");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [requiredRulingFields]);

  // ── Client-side filtering ───────────────────────────────────────────────────
  useEffect(() => {
    let results = Array.isArray(rulings) ? rulings : [];

    const query = (searchQuery || "").toLowerCase().trim();
    if (query) {
      results = results.filter((r) => {
        const title   = r?.title?.toLowerCase?.()        || "";
        const drug    = r?.drug_name?.toLowerCase?.()    || "";
        const manuf   = r?.manufacturer?.toLowerCase?.() || "";
        const summary = r?.summary?.toLowerCase?.()      || "";
        return (
          title.includes(query)   ||
          drug.includes(query)    ||
          manuf.includes(query)   ||
          summary.includes(query)
        );
      });
    }

    if (selectedTherapyAreas.length > 0)
      results = results.filter((r) => selectedTherapyAreas.includes(r?.therapy_area));
    if (selectedOutcomes.length > 0)
      results = results.filter((r) => selectedOutcomes.includes(r?.decision_outcome));
    if (selectedDossierCategories.length > 0)
      results = results.filter((r) => selectedDossierCategories.includes(r?.dossier_category));

    // ── YEAR FILTER: apply year filter ────────────────────────────────────────
    if (selectedYears.length > 0) {
      results = results.filter((r) => {
        const date       = r?.decision_date || "";
        const year       = date.length >= 4 ? date.substring(0, 4) : "";
        const isValidYear = /^\d{4}$/.test(year);
        if (isValidYear && selectedYears.includes(year)) return true;
        if (!isValidYear && selectedYears.includes("Unknown")) return true;
        return false;
      });
    }
    // ── YEAR FILTER end ────────────────────────────────────────────────────────

    setFilteredRulings(results);
    resetPage();
  }, [
    searchQuery,
    selectedTherapyAreas,
    selectedOutcomes,
    selectedDossierCategories,
    selectedYears,      // ── YEAR FILTER dependency
    rulings,
  ]);

  // ── Toggle helpers ──────────────────────────────────────────────────────────
  const toggleTherapyArea = (area) =>
    setSelectedTherapyAreas((prev) =>
      prev.includes(area) ? prev.filter((a) => a !== area) : [...prev, area]
    );

  const toggleOutcome = (outcome) =>
    setSelectedOutcomes((prev) =>
      prev.includes(outcome) ? prev.filter((o) => o !== outcome) : [...prev, outcome]
    );

  const toggleDossierCategory = (dossier) =>
    setSelectedDossierCategories((prev) =>
      prev.includes(dossier) ? prev.filter((o) => o !== dossier) : [...prev, dossier]
    );

  // ── YEAR FILTER: toggle helper ─────────────────────────────────────────────
  const toggleYear = (year) =>
    setSelectedYears((prev) =>
      prev.includes(year) ? prev.filter((y) => y !== year) : [...prev, year]
    );
  // ── YEAR FILTER end ────────────────────────────────────────────────────────

  // ── Search handler ──────────────────────────────────────────────────────────
  const handleSearch = async () => {
    console.log("Search button clicked, query:", searchQuery);
    setIsSearching(true);
    setBackendAnswer("");
    setBackendSources([]);
    resetPage();

    try {
      const response = await axios.post(`${API}/search-input`, {
        query: searchQuery,
      });
      console.log("Backend response:", response.data);
      setBackendAnswer(response.data?.result   || "");
      setBackendSources(response.data?.sources || []);
    } catch (err) {
      console.error("Backend call failed", err);
      setBackendAnswer("Error calling backend.");
      setBackendSources([]);
    } finally {
      setIsSearching(false);
    }
  };

  // ── Clear handlers ──────────────────────────────────────────────────────────
  const handleClearSearch = () => {
    setSearchQuery("");
    setBackendAnswer("");
    setBackendSources([]);
    setIsSearching(false);
    setSelectedTherapyAreas([]);
    setSelectedOutcomes([]);
    setSelectedDossierCategories([]);
    setSelectedYears([]);       // ── YEAR FILTER: clear
    setFilteredRulings(rulings);
    resetPage();
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedTherapyAreas([]);
    setSelectedOutcomes([]);
    setSelectedDossierCategories([]);
    setSelectedYears([]);       // ── YEAR FILTER: clear
    resetPage();
  };

  const hasActiveFilters =
    Boolean(searchQuery)                 ||
    selectedTherapyAreas.length > 0      ||
    selectedOutcomes.length > 0          ||
    selectedDossierCategories.length > 0 ||
    selectedYears.length > 0;            // ── YEAR FILTER: active check

  // ── Page-level loading skeleton ─────────────────────────────────────────────
  if (loading) {
    return (
      <div className="flex" data-testid="search-loading">
        <div className="filter-sidebar">
          <Skeleton className="h-8 w-32 mb-6" />
          <Skeleton className="h-10 w-full mb-8" />
          <Skeleton className="h-6 w-24 mb-4" />
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-6 w-full mb-3" />
          ))}
        </div>
        <div className="flex-1 p-8">
          <Skeleton className="h-10 w-64 mb-8" />
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-40 w-full rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── Main render ─────────────────────────────────────────────────────────────
  return (
    <div
      className="min-h-screen w-screen overflow-y-scroll"
      data-testid="search-page"
    >
      <div className="max-w-full px-6 py-6">

        {/* ── TOP SEARCH SECTION ── */}
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="w-full max-w-4xl">
            <h1 className="text-3xl font-bold text-slate-900 font-heading mb-6 text-center">
              Past Ruling Search
            </h1>

            {/* Search input row */}
            <div className="flex items-center gap-3 mb-4">
              <div className="relative flex-1">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  type="text"
                  placeholder="Search rulings..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="pl-10"
                  data-testid="search-input"
                  disabled={isSearching}
                />
              </div>

              <Button
                onClick={handleSearch}
                data-testid="search-button"
                className="whitespace-nowrap px-6"
                disabled={isSearching}
              >
                {isSearching ? (
                  <>
                    <Spinner className="w-4 h-4 mr-2 text-white" />
                    Searching…
                  </>
                ) : (
                  "Search"
                )}
              </Button>

              <Button
                variant="outline"
                onClick={handleClearSearch}
                disabled={isSearching}
              >
                Clear
              </Button>
            </div>

            {/* ── BACKEND RESULT AREA ── */}
            {isSearching ? (
              <div
                className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-md px-4 py-3 text-sm text-slate-500"
                data-testid="search-waiting"
                role="status"
                aria-live="polite"
              >
                <Spinner className="w-4 h-4 text-slate-400 shrink-0" />
                <span>Analysing your query, please wait…</span>
                <span className="flex gap-1 ml-auto">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }}
                    />
                  ))}
                </span>
              </div>
            ) : (
              <ResultBox
                answer={backendAnswer}
                sources={backendSources}
                data-testid="backend-result"
              />
            )}
          </div>
        </div>

        {/* ── SUBTITLE ── */}
        <div className="border-b pb-6 mb-8">
          <div className="w-full max-w-4xl mx-auto">
            <h2 className="text-xl font-semibold text-slate-900 text-center">
              Browse and filter historical HTA rulings from Zorginstituut Nederland
            </h2>
          </div>
        </div>

        {/* ── MAIN 2-COLUMN LAYOUT ── */}
        <div className="flex gap-8 min-w-0">

          {/* ── LEFT: FILTERS ── */}
          <aside
            className="w-72 shrink-0 filter-sidebar"
            data-testid="filter-sidebar"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Filters
              </h2>
              {hasActiveFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="text-slate-500 hover:text-slate-700"
                  data-testid="clear-filters-btn"
                >
                  <X className="w-4 h-4 mr-1" />
                  Clear
                </Button>
              )}
            </div>

            {/* Therapy Area */}
            <div className="filter-section">
              <h3 className="filter-label">Therapy Area</h3>
              {(therapyAreas || []).map((area) => (
                <div key={area} className="flex items-center gap-2 mb-2">
                  <Checkbox
                    checked={selectedTherapyAreas.includes(area)}
                    onCheckedChange={() => toggleTherapyArea(area)}
                  />
                  <Label>{area}</Label>
                </div>
              ))}
            </div>

            {/* Decision Outcome */}
            <div className="filter-section mt-6">
              <h3 className="filter-label">Decision Outcome</h3>
              {(decisionOutcomes || []).map((outcome) => (
                <div key={outcome} className="flex items-center gap-2 mb-2">
                  <Checkbox
                    checked={selectedOutcomes.includes(outcome)}
                    onCheckedChange={() => toggleOutcome(outcome)}
                  />
                  <Label>{outcome}</Label>
                </div>
              ))}
            </div>

            {/* ── YEAR FILTER: Year section ──────────────────────────────────── */}
            {(availableYears.length > 0 || hasUnknownDateRulings) && (
              <div className="filter-section mt-6">
                <h3 className="filter-label">Year</h3>

                {/* Known years — descending (most recent first) */}
                {availableYears.map((year) => (
                  <div key={year} className="flex items-center gap-2 mb-2">
                    <Checkbox
                      checked={selectedYears.includes(year)}
                      onCheckedChange={() => toggleYear(year)}
                      data-testid={`year-filter-${year}`}
                    />
                    <Label>{year}</Label>
                  </div>
                ))}

                {/* Unknown date bucket — only shown when such rulings exist */}
                {hasUnknownDateRulings && (
                  <div className="flex items-center gap-2 mb-2">
                    <Checkbox
                      checked={selectedYears.includes("Unknown")}
                      onCheckedChange={() => toggleYear("Unknown")}
                      data-testid="year-filter-unknown"
                    />
                    <Label className="text-slate-400 italic">Unknown date</Label>
                  </div>
                )}
              </div>
            )}
            {/* ── YEAR FILTER end ───────────────────────────────────────────── */}

          </aside>

          {/* ── RIGHT: RESULTS ── */}
          <div className="flex-1 min-w-0">
            <div className="p-8">

              {/* Error banner */}
              {fetchError && (
                <div
                  className="mb-6 p-3 rounded-md bg-amber-50 text-amber-800 border border-amber-200"
                  data-testid="search-error"
                >
                  {fetchError}. Check the browser console for details.
                </div>
              )}

              {/* Results count + range info + active filter badges */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <p className="text-slate-600">
                    <span className="font-semibold text-slate-900">
                      {filteredRulings.length}
                    </span>{" "}
                    rulings found
                  </p>
                  {filteredRulings.length > 0 && (
                    <span className="text-xs text-slate-400 border-l border-slate-200 pl-3">
                      Showing{" "}
                      <span className="font-medium text-slate-600">
                        {(currentPage - 1) * PAGE_SIZE + 1}–
                        {Math.min(currentPage * PAGE_SIZE, filteredRulings.length)}
                      </span>
                    </span>
                  )}
                </div>

                {/* Active filter badges */}
                {hasActiveFilters && (
                  <div className="flex items-center gap-2 flex-wrap">
                    {selectedTherapyAreas.map((area) => (
                      <Badge key={area} variant="secondary" className="text-xs">
                        {area}
                        <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => toggleTherapyArea(area)} />
                      </Badge>
                    ))}
                    {selectedOutcomes.map((outcome) => (
                      <Badge key={outcome} variant="secondary" className="text-xs">
                        {outcome}
                        <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => toggleOutcome(outcome)} />
                      </Badge>
                    ))}
                    {selectedDossierCategories.map((dossier) => (
                      <Badge key={dossier} variant="secondary" className="text-xs">
                        {dossier}
                        <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => toggleDossierCategory(dossier)} />
                      </Badge>
                    ))}

                    {/* ── YEAR FILTER: active year badges ───────────────────── */}
                    {selectedYears.map((year) => (
                      <Badge key={year} variant="secondary" className="text-xs">
                        {year === "Unknown" ? "Unknown date" : year}
                        <X className="w-3 h-3 ml-1 cursor-pointer" onClick={() => toggleYear(year)} />
                      </Badge>
                    ))}
                    {/* ── YEAR FILTER end ───────────────────────────────────── */}

                  </div>
                )}
              </div>

              {/* Results list / empty state */}
              {filteredRulings.length === 0 ? (
                <div className="empty-state" data-testid="no-results">
                  <FileText className="empty-state-icon" />
                  <h3 className="empty-state-title">No rulings found</h3>
                  <p className="empty-state-description">
                    Try adjusting your search criteria or filters to find relevant rulings.
                  </p>
                  <Button onClick={clearFilters} className="mt-4" variant="outline">
                    Clear All Filters
                  </Button>
                </div>
              ) : (
                <>
                  <div className="space-y-4">
                    {paginatedRulings.map((ruling, index) => {
                      const id           = ruling?.id               ?? `ruling-${index}`;
                      const outcome      = ruling?.decision_outcome  ?? "Unknown";
                      const area         = ruling?.therapy_area      ?? "Unknown area";
                      const dossier      = ruling?.dossier_category  ?? "Unknown dossier";
                      const title        = ruling?.title             ?? "Untitled ruling";
                      const drug         = ruling?.drug_name         ?? "Unknown drug";
                      const summary      = ruling?.summary           ?? "No summary available.";
                      const manufacturer = ruling?.manufacturer      ?? "Unknown manufacturer";
                      const decisionDate = ruling?.decision_date     ?? null;
                      const tags         = Array.isArray(ruling?.tags) ? ruling.tags : [];

                      return (
                        <Link
                          key={id}
                          to={ruling?.id != null ? `/ruling/${ruling.id}` : "#"}
                          className={`block animate-fade-in-up stagger-${Math.min(index + 1, 5)}`}
                          data-testid={`search-result-${id}`}
                        >
                          <Card className="ruling-card">
                            <CardContent className="p-5">
                              <div className="flex items-start justify-between gap-4">
                                <div className="flex-1 min-w-0">

                                  {/* Header row */}
                                  <div className="flex items-center gap-3 mb-3">
                                    <Badge className={`text-xs ${getOutcomeBadgeClass(outcome)}`}>
                                      {outcome}
                                    </Badge>
                                    <Badge variant="outline" className="text-xs">{area}</Badge>
                                    <Badge variant="outline" className="text-xs">{dossier}</Badge>
                                  </div>

                                  {/* Title */}
                                  <h3 className="text-lg font-semibold text-slate-900 mb-2 font-heading">
                                    {title}
                                  </h3>

                                  {/* Drug name */}
                                  <p className="text-sm text-sky-600 font-medium mb-2">{drug}</p>

                                  {/* Summary */}
                                  <p className="text-sm text-slate-600 line-clamp-2 mb-3">{summary}</p>

                                  {/* Meta */}
                                  <div className="flex items-center gap-4">
                                    <span className="text-xs text-slate-500 flex items-center gap-1">
                                      <Building2 className="w-3 h-3" />
                                      {manufacturer}
                                    </span>
                                    {/* ── YEAR FILTER: show Unknown date label when missing ── */}
                                    <span
                                      className={`text-xs flex items-center gap-1 ${
                                        decisionDate ? "text-slate-500" : "text-slate-400 italic"
                                      }`}
                                    >
                                      <Calendar className="w-3 h-3" />
                                      {decisionDate ?? "Unknown date"}
                                    </span>
                                    {/* ── YEAR FILTER end ─────────────────────────────────── */}
                                  </div>

                                  {/* Tags */}
                                  {tags.length > 0 && (
                                    <div className="flex items-center gap-2 mt-3">
                                      {tags.slice(0, 4).map((tag) => (
                                        <Badge
                                          key={tag}
                                          variant="outline"
                                          className="text-xs text-slate-500 bg-slate-50"
                                        >
                                          {tag}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                </div>
                                <ChevronRight className="w-5 h-5 text-slate-300 flex-shrink-0 mt-2" />
                              </div>
                            </CardContent>
                          </Card>
                        </Link>
                      );
                    })}
                  </div>

                  {/* ── PAGINATION ── */}
                  <PaginationControls
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                  />
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}