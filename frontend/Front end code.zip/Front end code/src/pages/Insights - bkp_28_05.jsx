import { useState, useEffect, useMemo, useRef } from "react";
import axios from "axios";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Skeleton } from "../components/ui/skeleton";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import {
  BarChart3,
  TrendingUp,
  AlertCircle,
  FileText,
  Building2,
  Calendar,
  Activity,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Download,
} from "lucide-react";
import {
  BarChart as RBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from "recharts";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

if (process.env.NODE_ENV === "development" && !axios.__LOG_INTERCEPTORS__) {
  axios.__LOG_INTERCEPTORS__ = true;
  axios.interceptors.request.use((cfg) => {
    console.log("[REQ]", cfg.method?.toUpperCase(), cfg.url);
    return cfg;
  });
  axios.interceptors.response.use(
    (res) => { console.log("[RES]", res.status, res.config?.url); return res; },
    (err) => { console.error("[ERR]", err.message); return Promise.reject(err); }
  );
}

const seenWarnings = new Set();
function warnOnce(key, payload) {
  if (!seenWarnings.has(key)) { console.warn(key, payload); seenWarnings.add(key); }
}

function buildWindowOptions(trendData) {
  if (!Array.isArray(trendData) || trendData.length === 0) return [];
  const windows = [];
  for (let i = 0; i < trendData.length; i += 6) {
    const slice = trendData.slice(i, i + 6);
    const first = slice[0]?.month ?? "";
    const last  = slice[slice.length - 1]?.month ?? "";
    windows.push({
      label:    first === last ? first : `${first} – ${last}`,
      startIdx: i,
      endIdx:   Math.min(i + 6, trendData.length),
    });
  }
  return windows;
}

function deriveTrendLabel(trendData) {
  if (!Array.isArray(trendData) || trendData.length === 0)
    return "Monthly Decision Trends";
  const months = trendData.map((d) => d.month).filter(Boolean);
  if (months.length === 0) return "Monthly Decision Trends";
  const first = months[0];
  const last  = months[months.length - 1];
  const years = [...new Set(months.map((m) => m.split(" ")[1]).filter(Boolean))];
  if (years.length === 1) return `Monthly Decision Trends (${years[0]})`;
  return `Monthly Decision Trends (${first} – ${last})`;
}

// ─── Derive Key Insights from live data ──────────────────────────────────────
function deriveKeyInsights({ visibleTrendData, insights, rulings, avgReviewDays }) {
  const totalRulings  = insights?.total_rulings ?? 0;
  const positive      = insights?.positive_decisions ?? 0;
  const negative      = insights?.negative_decisions ?? 0;
  const conditional   = insights?.conditional_decisions ?? 0;
  const approvalRate  = totalRulings ? Math.round((positive / totalRulings) * 100) : 0;

  const windowPositive    = visibleTrendData.reduce((s, d) => s + (d.positive    ?? 0), 0);
  const windowNegative    = visibleTrendData.reduce((s, d) => s + (d.negative    ?? 0), 0);
  const windowConditional = visibleTrendData.reduce((s, d) => s + (d.conditional ?? 0), 0);
  const windowTotal       = windowPositive + windowNegative + windowConditional;
  const windowPeriod      = visibleTrendData.length > 0
    ? `${visibleTrendData[0].month} – ${visibleTrendData[visibleTrendData.length - 1].month}`
    : "selected period";

  const therapyBreakdown = insights?.therapy_area_breakdown ?? {};
  const topTherapyAreas  = Object.entries(therapyBreakdown)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([name]) => name);

  const dominantOutcome =
    windowPositive >= windowNegative && windowPositive >= windowConditional
      ? "positive"
      : windowNegative >= windowConditional
      ? "negative"
      : "conditional";

  const visibleMonthSet = new Set(visibleTrendData.map((d) => d.month));

  const windowRulings = Array.isArray(rulings)
    ? rulings.filter((r) => {
        const raw = r?.decision_date ?? "";
        if (!raw || raw.length < 7) return false;
        try {
          const dt = new Date(raw.slice(0, 7) + "-01");
          const label = dt.toLocaleString("en-US", { month: "short", year: "numeric" });
          return visibleMonthSet.has(label);
        } catch { return false; }
      })
    : [];

  const positiveWindowRulings = windowRulings.filter(
    (r) => r?.decision_outcome === "Positive"
  );
  const positiveTherapyCounts = {};
  positiveWindowRulings.forEach((r) => {
    const area = r?.therapy_area ?? "Unknown";
    positiveTherapyCounts[area] = (positiveTherapyCounts[area] ?? 0) + 1;
  });
  const topPositiveAreas = Object.entries(positiveTherapyCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([name]) => name);

  const negativeWindowRulings = windowRulings.filter(
    (r) =>
      r?.decision_outcome === "Negative" ||
      (r?.decision_outcome ?? "").includes("Conditions")
  );
  const negativeTherapyCounts = {};
  negativeWindowRulings.forEach((r) => {
    const area = r?.therapy_area ?? "Unknown";
    negativeTherapyCounts[area] = (negativeTherapyCounts[area] ?? 0) + 1;
  });
  const topNegativeAreas = Object.entries(negativeTherapyCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([name]) => name);

  const dossierCounts = {};
  windowRulings.forEach((r) => {
    const cat = r?.dossier_category ?? "Unknown";
    dossierCounts[cat] = (dossierCounts[cat] ?? 0) + 1;
  });
  const topDossiers = Object.entries(dossierCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([name]) => name);

  const mfrCounts = {};
  windowRulings.forEach((r) => {
    const mfr = r?.manufacturer;
    if (mfr) mfrCounts[mfr] = (mfrCounts[mfr] ?? 0) + 1;
  });
  const topMfrInWindow = Object.entries(mfrCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 1)
    .map(([name]) => name)[0] ?? null;

  const successItems = [
    approvalRate > 0
      ? `Overall approval rate: ${approvalRate}% across ${totalRulings} rulings`
      : null,
    windowPositive > 0
      ? `${windowPositive} positive decision${windowPositive !== 1 ? "s" : ""} in ${windowPeriod}`
      : null,
    topPositiveAreas.length > 0
      ? `Leading areas: ${topPositiveAreas.join(", ")}`
      : topTherapyAreas.length > 0
      ? `Top therapy areas: ${topTherapyAreas.join(", ")}`
      : null,
    topMfrInWindow
      ? `Most active manufacturer: ${topMfrInWindow}`
      : null,
    dominantOutcome === "positive" && windowTotal > 0
      ? `Positive outcomes dominate this period (${Math.round((windowPositive / windowTotal) * 100)}%)`
      : null,
  ].filter(Boolean).slice(0, 4);

  const objectionItems = [
    windowNegative > 0
      ? `${windowNegative} negative decision${windowNegative !== 1 ? "s" : ""} in ${windowPeriod}`
      : "No negative decisions in this period",
    windowConditional > 0
      ? `${windowConditional} conditional approval${windowConditional !== 1 ? "s" : ""} — conditions attached`
      : null,
    topNegativeAreas.length > 0
      ? `Challenged areas: ${topNegativeAreas.join(", ")}`
      : null,
    negative > 0
      ? `${negative} total negative decisions across all rulings`
      : null,
    conditional > 0
      ? `${conditional} total conditional decisions — review conditions carefully`
      : null,
  ].filter(Boolean).slice(0, 4);

  const focusItems = [
    topTherapyAreas.length > 0
      ? `Highest volume: ${topTherapyAreas[0]} (${therapyBreakdown[topTherapyAreas[0]] ?? 0} rulings)`
      : null,
    topTherapyAreas.length > 1
      ? `Also active: ${topTherapyAreas.slice(1).join(", ")}`
      : null,
    topDossiers.length > 0
      ? `Dominant dossier type: ${topDossiers[0]}`
      : "Pharmacotherapeutic dossiers most common",
    topDossiers.length > 1
      ? `Secondary dossier: ${topDossiers[1]}`
      : "Cost-effectiveness analysis quality critical",
    windowTotal > 0
      ? `${windowTotal} total decisions in ${windowPeriod}`
      : null,
  ].filter(Boolean).slice(0, 4);

  const timelineItems = [
    avgReviewDays > 0 ? `Avg assessment: ${avgReviewDays} days` : "Avg assessment: N/A",
    visibleTrendData.length > 0
      ? `Current window: ${visibleTrendData.length} month${visibleTrendData.length !== 1 ? "s" : ""} (${windowPeriod})`
      : null,
    dominantOutcome === "positive"
      ? "Trend: positive decisions leading this period"
      : dominantOutcome === "negative"
      ? "Trend: negative decisions elevated — review submissions"
      : "Trend: conditional approvals prominent this period",
    windowTotal > 0 && windowPositive > 0
      ? `Window approval rate: ${Math.round((windowPositive / windowTotal) * 100)}%`
      : null,
  ].filter(Boolean).slice(0, 4);

  return { successItems, objectionItems, focusItems, timelineItems, windowPeriod };
}

export default function Insights() {
  const [insights, setInsights]         = useState(null);
  const [rulings, setRulings]           = useState([]);
  const [loading, setLoading]           = useState(true);
  const [windowIdx, setWindowIdx]       = useState(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);
  const dropdownRef = useRef(null);
  const headerRef   = useRef(null);
  const exportRef   = useRef(null);
  const [showAllMfr, setShowAllMfr] = useState(false);

  const expectedInsightFields = useMemo(() => [
    "total_rulings", "positive_decisions", "conditional_decisions",
    "negative_decisions", "avg_review_time_days", "therapy_area_breakdown",
    "top_manufacturers", "all_manufacturers", "monthly_trends",
  ], []);

  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target))
        setDropdownOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      try {
        const [insightsRes, rulingsRes] = await Promise.allSettled([
          axios.get(`${API}/insights`),
          axios.get(`${API}/rulings`),
        ]);

        if (insightsRes.status === "fulfilled") {
          const data = insightsRes.value?.data;
          if (!data || typeof data !== "object") {
            warnOnce("Expected insights object, got:", data);
            setInsights(null);
          } else {
            expectedInsightFields.forEach((f) => {
              if (data?.[f] == null) warnOnce(`insights missing field: ${f}`, data);
            });
            setInsights(data);
          }
        } else {
          console.error("Failed to fetch insights:", insightsRes.reason);
          setInsights(null);
        }

        if (rulingsRes.status === "fulfilled") {
          const data = rulingsRes.value?.data;
          setRulings(Array.isArray(data) ? data : []);
        } else {
          console.error("Failed to fetch rulings:", rulingsRes.reason);
          setRulings([]);
        }
      } catch (error) {
        console.error("Unexpected fetch error:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, [expectedInsightFields]);

  const trendData = useMemo(
    () => (Array.isArray(insights?.monthly_trends) ? insights.monthly_trends : []),
    [insights]
  );

  const windowOptions = useMemo(() => buildWindowOptions(trendData), [trendData]);

  useEffect(() => {
    if (windowOptions.length > 0 && windowIdx === null) {
      setWindowIdx(windowOptions.length - 1);
    }
  }, [windowOptions, windowIdx]);

  const visibleTrendData = useMemo(() => {
    if (windowIdx === null || windowOptions.length === 0) return trendData;
    const w = windowOptions[windowIdx];
    return trendData.slice(w.startIdx, w.endIdx);
  }, [trendData, windowOptions, windowIdx]);

  const therapyAreaData = useMemo(() =>
    insights?.therapy_area_breakdown &&
    typeof insights.therapy_area_breakdown === "object"
      ? Object.entries(insights.therapy_area_breakdown).map(([name, value]) => ({ name, value }))
      : [],
    [insights]
  );

  const manufacturersToDisplay = useMemo(() =>
    showAllMfr
      ? (insights?.all_manufacturers ?? insights?.top_manufacturers ?? [])
      : (insights?.top_manufacturers ?? []),
    [showAllMfr, insights]
  );

  const hasMoreManufacturers =
    (insights?.all_manufacturers?.length ?? 0) >
    (insights?.top_manufacturers?.length ?? 0);

  const avgReviewDays = insights?.avg_review_time_days ?? 0;

  const { successItems, objectionItems, focusItems, timelineItems, windowPeriod } =
    useMemo(() =>
      deriveKeyInsights({ visibleTrendData, insights, rulings, avgReviewDays }),
      [visibleTrendData, insights, rulings, avgReviewDays]
    );

  // ── Export to PDF ─────────────────────────────────────────────────────────
  const exportToPdf = async () => {
    const headerNode  = headerRef.current;
    const contentNode = exportRef.current;

    if (!contentNode) {
      toast.error("Nothing to export");
      return;
    }

    setExportLoading(true);

    try {
      const pdf        = new jsPDF("p", "mm", "a4");
      const pageWidth  = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin     = 10;
      const availableWidth = pageWidth - margin * 2;

      const pxToMm = (px) => (px * 25.4) / 96;
      const mmToPx = (mm) => (mm * 96)   / 25.4;

      const renderNode = async (node) => {
        const originalBg = node.style.backgroundColor;
        node.style.backgroundColor = "#ffffff";
        const canvas = await html2canvas(node, {
          scale:           2,
          useCORS:         true,
          backgroundColor: "#ffffff",
          logging:         process.env.NODE_ENV === "development",
        });
        node.style.backgroundColor = originalBg || "";
        return canvas;
      };

      const addCanvasToPdf = (canvas, startYMm) => {
        const imgData     = canvas.toDataURL("image/png");
        const imgWidthPx  = canvas.width;
        const imgHeightPx = canvas.height;

        const imgWidthMm  = availableWidth;
        const imgHeightMm = (imgHeightPx / imgWidthPx) * imgWidthMm;

        let remainingMm    = imgHeightMm;
        let sourceOffsetPx = 0;

        const firstSliceHeightMm = Math.min(remainingMm, pageHeight - startYMm - margin);
        const firstSliceHeightPx = (firstSliceHeightMm / imgHeightMm) * imgHeightPx;

        pdf.addImage(
          imgData, "PNG",
          margin, startYMm,
          imgWidthMm, firstSliceHeightMm,
          undefined, "FAST"
        );

        sourceOffsetPx += firstSliceHeightPx;
        remainingMm    -= firstSliceHeightMm;

        if (remainingMm > 0) {
          const sliceCanvas = document.createElement("canvas");
          const ctx         = sliceCanvas.getContext("2d");
          const scaleX      = imgWidthMm / pxToMm(imgWidthPx);
          const pageBodyPx  = Math.floor(mmToPx(pageHeight - margin * 2));

          while (sourceOffsetPx < imgHeightPx) {
            const sliceHeightPx = Math.min(
              imgHeightPx - sourceOffsetPx,
              Math.floor(pageBodyPx / scaleX)
            );

            sliceCanvas.width  = Math.floor(mmToPx(availableWidth));
            sliceCanvas.height = Math.floor(sliceHeightPx * scaleX);

            ctx.fillStyle = "#ffffff";
            ctx.fillRect(0, 0, sliceCanvas.width, sliceCanvas.height);
            ctx.drawImage(
              canvas,
              0, sourceOffsetPx,
              imgWidthPx, sliceHeightPx,
              0, 0,
              sliceCanvas.width, sliceCanvas.height
            );

            pdf.addPage();
            pdf.addImage(
              sliceCanvas.toDataURL("image/png"), "PNG",
              margin, margin,
              availableWidth, pageHeight - margin * 2,
              undefined, "FAST"
            );

            sourceOffsetPx += sliceHeightPx;
          }

          return margin + pxToMm(
            (sourceOffsetPx - (imgHeightPx - firstSliceHeightPx)) * scaleX
          );
        }

        return startYMm + firstSliceHeightMm + 4;
      };

      let nextYMm = margin;

      if (headerNode) {
        const exportBtn = headerNode.querySelector("[data-testid='insights-download-btn']");
        if (exportBtn) exportBtn.style.visibility = "hidden";

        const headerCanvas = await renderNode(headerNode);

        if (exportBtn) exportBtn.style.visibility = "";

        nextYMm = addCanvasToPdf(headerCanvas, nextYMm);
      }

      addCanvasToPdf(await renderNode(contentNode), nextYMm);

      pdf.save(`insights_export_${new Date().toISOString().slice(0, 10)}.pdf`);
      toast.success("PDF exported");

    } catch (e) {
      console.error("PDF export failed:", e);
      toast.error("Failed to export PDF");
    } finally {
      setExportLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8" data-testid="insights-loading">
        <Skeleton className="h-10 w-64 mb-8" />
        <div className="grid grid-cols-4 gap-6 mb-8">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
        <div className="grid grid-cols-2 gap-6">
          <Skeleton className="h-80 rounded-xl" />
          <Skeleton className="h-80 rounded-xl" />
        </div>
      </div>
    );
  }

  const totalRulings    = insights?.total_rulings         ?? 0;
  const positive        = insights?.positive_decisions    ?? 0;
  const conditional     = insights?.conditional_decisions ?? 0;
  const negative        = insights?.negative_decisions    ?? 0;
  const approvalRate    = totalRulings ? Math.round((positive    / totalRulings) * 100) : 0;
  const conditionalRate = totalRulings ? Math.round((conditional / totalRulings) * 100) : 0;
  const isFirstWindow   = windowIdx === 0;
  const isLastWindow    = windowIdx === windowOptions.length - 1;
  const trendChartTitle = deriveTrendLabel(visibleTrendData);

  const outcomeData = [
    { name: "Positive",    value: positive,    color: "#10B981" },
    { name: "Conditional", value: conditional, color: "#F59E0B" },
    { name: "Negative",    value: negative,    color: "#EF4444" },
  ];

  return (
    <div data-testid="insights-page">
      {/* Header */}
      <header className="page-header" ref={headerRef}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-sky-100 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-sky-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 font-heading">
                Insights &amp; Analytics
              </h1>
              <p className="text-slate-500">
                Trends and patterns from ZIN HTA assessments
              </p>
            </div>
          </div>

          {/* Export PDF Button */}
          <Button
            variant="outline"
            size="sm"
            data-testid="insights-download-btn"
            onClick={exportToPdf}
            disabled={exportLoading}
            title="Export insights as PDF"
          >
            {exportLoading ? (
              <>
                <svg
                  className="w-4 h-4 mr-2 animate-spin"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12" cy="12" r="10"
                    stroke="currentColor" strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8v8H4z"
                  />
                </svg>
                Exporting...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Export PDF
              </>
            )}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="p-8" ref={exportRef}>
        {/* ── Summary Metrics ──────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="metric-card animate-fade-in-up stagger-1" data-testid="insight-total">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="metric-value">{totalRulings}</p>
                  <p className="metric-label">Total Assessments</p>
                </div>
                <div className="w-12 h-12 bg-sky-100 rounded-xl flex items-center justify-center">
                  <FileText className="w-6 h-6 text-sky-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="metric-card animate-fade-in-up stagger-2" data-testid="insight-positive-rate">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="metric-value text-emerald-600">{approvalRate}%</p>
                  <p className="metric-label">Approval Rate</p>
                </div>
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="metric-card animate-fade-in-up stagger-3" data-testid="insight-conditional-rate">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="metric-value text-amber-600">{conditionalRate}%</p>
                  <p className="metric-label">Conditional Rate</p>
                </div>
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="metric-card animate-fade-in-up stagger-4" data-testid="insight-review-time">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="metric-value">{avgReviewDays}</p>
                  <p className="metric-label">Avg Review Days</p>
                </div>
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-slate-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* ── Charts Row ───────────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="chart-container" data-testid="outcome-chart">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                Decision Outcomes Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={outcomeData} cx="50%" cy="50%"
                      innerRadius={60} outerRadius={100} paddingAngle={2} dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {outcomeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="chart-container" data-testid="therapy-area-chart">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                Rulings by Therapy Area
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                {therapyAreaData.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-sm text-slate-400">
                    No therapy area data available.
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <RBarChart data={therapyAreaData} layout="vertical" margin={{ left: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 12 }} />
                      <Tooltip />
                      <Bar dataKey="value" fill="#0284C7" radius={[0, 4, 4, 0]} barSize={24} />
                    </RBarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* ── Monthly Trends ───────────────────────────────────────────────── */}
        <Card className="chart-container mb-8" data-testid="trends-chart">
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-3">
                <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                  {trendChartTitle}
                </CardTitle>
                {trendData.length > 0 && (
                  <Badge variant="outline" className="text-xs text-emerald-700 border-emerald-300 bg-emerald-50">
                    {trendData.length} month{trendData.length !== 1 ? "s" : ""}
                  </Badge>
                )}
              </div>

              {windowOptions.length > 1 && (
                <div className="flex items-center gap-1" ref={dropdownRef}>
                  <button
                    onClick={() => setWindowIdx((i) => Math.max(0, (i ?? 0) - 1))}
                    disabled={isFirstWindow}
                    title="Previous 6 months"
                    data-testid="trend-prev-btn"
                    className="h-8 w-8 flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 hover:border-slate-300 disabled:opacity-30 disabled:cursor-not-allowed transition-colors shadow-sm"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <div className="relative">
                    <button
                      onClick={() => setDropdownOpen((o) => !o)}
                      data-testid="trend-window-dropdown-btn"
                      className="flex items-center gap-1.5 h-8 px-3 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:border-slate-300 hover:bg-slate-50 transition-colors shadow-sm min-w-[168px] justify-between"
                    >
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">
                          {windowIdx !== null ? windowOptions[windowIdx]?.label : "All periods"}
                        </span>
                      </div>
                      <ChevronDown className={`w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform duration-150 ${dropdownOpen ? "rotate-180" : ""}`} />
                    </button>

                    {dropdownOpen && (
                      <div
                        className="absolute right-0 top-full mt-1.5 z-30 bg-white border border-slate-200 rounded-xl shadow-xl py-1 min-w-[180px] max-h-64 overflow-y-auto"
                        data-testid="trend-window-dropdown-menu"
                      >
                        <button
                          onClick={() => { setWindowIdx(null); setDropdownOpen(false); }}
                          className={`w-full text-left px-4 py-2 text-xs transition-colors border-b border-slate-100 ${windowIdx === null ? "bg-sky-50 text-sky-700 font-semibold" : "text-slate-500 hover:bg-slate-50"}`}
                        >
                          All periods
                        </button>
                        {windowOptions.map((opt, idx) => (
                          <button
                            key={idx}
                            onClick={() => { setWindowIdx(idx); setDropdownOpen(false); }}
                            data-testid={`trend-window-option-${idx}`}
                            className={`w-full text-left px-4 py-2 text-xs transition-colors ${windowIdx === idx ? "bg-sky-50 text-sky-700 font-semibold" : "text-slate-600 hover:bg-slate-50"}`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <button
                    onClick={() => setWindowIdx((i) => Math.min(windowOptions.length - 1, (i ?? 0) + 1))}
                    disabled={isLastWindow}
                    title="Next 6 months"
                    data-testid="trend-next-btn"
                    className="h-8 w-8 flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 hover:border-slate-300 disabled:opacity-30 disabled:cursor-not-allowed transition-colors shadow-sm"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>

                  <span className="text-xs text-slate-400 ml-1 tabular-nums">
                    {windowIdx !== null ? `${windowIdx + 1} / ${windowOptions.length}` : `all ${windowOptions.length}`}
                  </span>
                </div>
              )}
            </div>
          </CardHeader>

          <CardContent>
            <div className="h-80">
              {trendData.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center gap-2 text-slate-400">
                  <BarChart3 className="w-10 h-10 text-slate-300" />
                  <p className="text-sm font-medium">No trend data available</p>
                  <p className="text-xs text-slate-400">Rulings need a valid decision_date to appear here.</p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={visibleTrendData} margin={{ top: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="positive"    stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} name="Positive" />
                    <Line type="monotone" dataKey="conditional" stroke="#F59E0B" strokeWidth={2} dot={{ r: 4 }} name="Conditional" />
                    <Line type="monotone" dataKey="negative"    stroke="#EF4444" strokeWidth={2} dot={{ r: 4 }} name="Negative" />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </CardContent>
        </Card>

        {/* ── Bottom Section ───────────────────────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* ── Top Manufacturers Table ── */}
          <Card className="border-slate-200" data-testid="top-mfrs-table">
            <CardHeader className="border-b border-slate-100 bg-slate-50/50">
              <CardTitle className="text-lg font-semibold text-slate-900 font-heading flex items-center gap-2">
                <Building2 className="w-5 h-5 text-slate-500" />
                Top Manufacturers
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Manufacturer</th>
                    <th>Rulings</th>
                  </tr>
                </thead>
                <tbody>
                  {manufacturersToDisplay.length > 0 ? (
                    manufacturersToDisplay.map((mfr, index) => (
                      <tr key={mfr?.name ?? `mfr-${index}`}>
                        <td>
                          <span className="w-6 h-6 bg-slate-100 rounded-full inline-flex items-center justify-center text-xs font-semibold">
                            {index + 1}
                          </span>
                        </td>
                        <td className="font-medium">{mfr?.name ?? "Unknown"}</td>
                        <td>
                          <Badge variant="secondary" className="font-mono">
                            {mfr?.count ?? 0}
                          </Badge>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="text-sm text-slate-500 p-4">No manufacturer data.</td>
                    </tr>
                  )}
                </tbody>
              </table>

              {hasMoreManufacturers && (
                <div className="px-4 pb-4 pt-2">
                  <button
                    onClick={() => setShowAllMfr((prev) => !prev)}
                    className="w-full text-xs font-medium text-sky-600 hover:text-sky-800 border border-sky-100 hover:border-sky-300 rounded-lg py-2 transition-colors duration-150 flex items-center justify-center gap-1"
                    data-testid="toggle-manufacturers-btn-insights"
                  >
                    {showAllMfr ? <>Show Less ▲</> : <>Show All ({insights?.all_manufacturers?.length ?? 0}) ▼</>}
                  </button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* ── Key Insights ── */}
          <Card className="lg:col-span-2 border-slate-200" data-testid="key-insights">
            <CardHeader className="border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <CardTitle className="text-lg font-semibold text-slate-900 font-heading flex items-center gap-2">
                  <Activity className="w-5 h-5 text-sky-500" />
                  Key Insights for HTA Submissions
                </CardTitle>
                {windowPeriod && (
                  <Badge variant="outline" className="text-xs text-sky-700 border-sky-200 bg-sky-50">
                    {windowPeriod}
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-5 h-5 text-emerald-600" />
                      <h4 className="font-semibold text-emerald-800">Success Factors</h4>
                    </div>
                    <ul className="text-sm text-emerald-700 space-y-1">
                      {successItems.length > 0
                        ? successItems.map((item, i) => <li key={i}>• {item}</li>)
                        : <li className="text-emerald-500 italic">No positive rulings in this period.</li>
                      }
                    </ul>
                  </div>

                  <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="w-5 h-5 text-amber-600" />
                      <h4 className="font-semibold text-amber-800">Common Objections</h4>
                    </div>
                    <ul className="text-sm text-amber-700 space-y-1">
                      {objectionItems.length > 0
                        ? objectionItems.map((item, i) => <li key={i}>• {item}</li>)
                        : <li className="text-amber-500 italic">No objections recorded in this period.</li>
                      }
                    </ul>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-sky-50 rounded-lg border border-sky-200">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="w-5 h-5 text-sky-600" />
                      <h4 className="font-semibold text-sky-800">ZIN Focus Areas</h4>
                    </div>
                    <ul className="text-sm text-sky-700 space-y-1">
                      {focusItems.length > 0
                        ? focusItems.map((item, i) => <li key={i}>• {item}</li>)
                        : <li className="text-sky-500 italic">No focus area data available.</li>
                      }
                    </ul>
                  </div>

                  <div className="p-4 bg-slate-100 rounded-lg border border-slate-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="w-5 h-5 text-slate-600" />
                      <h4 className="font-semibold text-slate-800">Timeline Insights</h4>
                    </div>
                    <ul className="text-sm text-slate-700 space-y-1">
                      {timelineItems.map((item, i) => <li key={i}>• {item}</li>)}
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}