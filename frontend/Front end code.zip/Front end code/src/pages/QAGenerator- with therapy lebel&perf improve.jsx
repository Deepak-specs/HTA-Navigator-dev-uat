// src/pages/QAGenerator.jsx
import { useState, useEffect, useMemo, useCallback, memo, useRef } from "react";
import axios from "axios";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";
import { Input } from "../components/ui/input";
import { Skeleton } from "../components/ui/skeleton";
import { ScrollArea } from "../components/ui/scroll-area";
import { Checkbox } from "../components/ui/checkbox";
import { Label } from "../components/ui/label";
import {
  BrainCircuit, FileText, Loader2, Copy, Download,
  ChevronRight, ChevronLeft, Sparkles, CheckCircle,
  Lightbulb, ChevronsLeft, ChevronsRight, BookOpen,
  MessageSquare, Filter, Search as SearchIcon, X,
  ShieldCheck, Stethoscope,
} from "lucide-react";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;
const RULINGS_PAGE_SIZE = 15;

// ─── Stable icon constants (Fix #4) ──────────────────────────────────────────
const FT_ICON  = <FileText    className="w-4 h-4" />;
const BIA_ICON = <BookOpen    className="w-4 h-4" />;
const FE_ICON  = <CheckCircle className="w-4 h-4" />;
const DEF_ICON = <Lightbulb   className="w-4 h-4" />;

// ─── Dossier colour palette ───────────────────────────────────────────────────
const DOSSIER_META = Object.freeze({
  FT: {
    colorHeader: "text-blue-800",   colorBadge: "bg-blue-100 text-blue-700",
    colorBorder: "border-blue-300", colorBg: "bg-blue-50",
    colorBar: "bg-blue-500",        colorIndex: "bg-blue-500 text-white",
    colorQ: "text-blue-600",        colorABg: "bg-blue-50 border-blue-200",
    colorALabel: "text-blue-500",   icon: FT_ICON,
  },
  BIA: {
    colorHeader: "text-emerald-800",   colorBadge: "bg-emerald-100 text-emerald-700",
    colorBorder: "border-emerald-300", colorBg: "bg-emerald-50",
    colorBar: "bg-emerald-500",        colorIndex: "bg-emerald-500 text-white",
    colorQ: "text-emerald-600",        colorABg: "bg-emerald-50 border-emerald-200",
    colorALabel: "text-emerald-500",   icon: BIA_ICON,
  },
  FE: {
    colorHeader: "text-purple-800",   colorBadge: "bg-purple-100 text-purple-700",
    colorBorder: "border-purple-300", colorBg: "bg-purple-50",
    colorBar: "bg-purple-500",        colorIndex: "bg-purple-500 text-white",
    colorQ: "text-purple-600",        colorABg: "bg-purple-50 border-purple-200",
    colorALabel: "text-purple-500",   icon: FE_ICON,
  },
});

const DEFAULT_META = Object.freeze({
  colorHeader: "text-slate-800",   colorBadge: "bg-slate-100 text-slate-700",
  colorBorder: "border-slate-300", colorBg: "bg-slate-50",
  colorBar: "bg-slate-400",        colorIndex: "bg-slate-400 text-white",
  colorQ: "text-slate-600",        colorABg: "bg-slate-50 border-slate-200",
  colorALabel: "text-slate-500",   icon: DEF_ICON,
});

const getMeta  = (code) => DOSSIER_META[code] || DEFAULT_META;
const impStyle = (imp)  => {
  switch ((imp || "").toLowerCase()) {
    case "high":   return { badge: "bg-red-100 text-red-700 border border-red-200",       dot: "bg-red-500"   };
    case "medium": return { badge: "bg-amber-100 text-amber-700 border border-amber-200", dot: "bg-amber-500" };
    default:       return { badge: "bg-slate-100 text-slate-600 border border-slate-200", dot: "bg-slate-400" };
  }
};

// ─── Grounding score colour helpers ──────────────────────────────────────────
const groundingBarColor = (score) => {
  if (score >= 80) return "bg-emerald-500";
  if (score >= 60) return "bg-amber-400";
  return "bg-red-400";
};

const groundingTextColor = (score) => {
  if (score >= 80) return "text-emerald-700";
  if (score >= 60) return "text-amber-600";
  return "text-red-600";
};

// ─── Debounce hook (Fix #3) ───────────────────────────────────────────────────
function useDebounce(value, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);
  return debounced;
}

// ─── Ruling panel pagination ──────────────────────────────────────────────────
const RulingPaginationControls = memo(function RulingPaginationControls({
  currentPage, totalPages, onPageChange,
}) {
  if (totalPages <= 1) return null;
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 bg-white">
      <span className="text-xs text-slate-500">
        <span className="font-semibold text-slate-700">{currentPage}</span>
        {" / "}
        <span className="font-semibold text-slate-700">{totalPages}</span>
      </span>
      <div className="flex items-center gap-1">
        <Button variant="outline" size="sm" className="h-7 w-7 p-0"
          disabled={currentPage === 1} onClick={() => onPageChange(1)}>
          <ChevronsLeft className="w-3.5 h-3.5" />
        </Button>
        <Button variant="outline" size="sm" className="h-7 w-7 p-0"
          disabled={currentPage === 1} onClick={() => onPageChange(currentPage - 1)}>
          <ChevronLeft className="w-3.5 h-3.5" />
        </Button>
        {Array.from({ length: totalPages }, (_, i) => i + 1)
          .filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
          .reduce((acc, p, idx, arr) => {
            if (idx > 0 && p - arr[idx - 1] > 1) acc.push("...");
            acc.push(p);
            return acc;
          }, [])
          .map((item, idx) =>
            item === "..." ? (
              <span key={`e-${idx}`}
                className="h-7 w-5 flex items-center justify-center text-xs text-slate-400">
                …
              </span>
            ) : (
              <Button key={item}
                variant={currentPage === item ? "default" : "outline"} size="sm"
                onClick={() => onPageChange(item)}
                className={`h-7 w-7 p-0 text-xs ${
                  currentPage === item
                    ? "bg-sky-600 hover:bg-sky-700 text-white border-sky-600"
                    : ""
                }`}>
                {item}
              </Button>
            )
          )}
        <Button variant="outline" size="sm" className="h-7 w-7 p-0"
          disabled={currentPage === totalPages} onClick={() => onPageChange(currentPage + 1)}>
          <ChevronRight className="w-3.5 h-3.5" />
        </Button>
        <Button variant="outline" size="sm" className="h-7 w-7 p-0"
          disabled={currentPage === totalPages} onClick={() => onPageChange(totalPages)}>
          <ChevronsRight className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
});

// ─── Single question card (Fix #2 — memo) ────────────────────────────────────
const QCard = memo(function QCard({ q, num, code, dossierName, therapyArea, onCopy }) {
  const m  = getMeta(code);
  const is = impStyle(q.importance);

  const groundingMetricKeys = ["faithfulness", "relevance", "coherence", "groundedness"];
  const groundingMetricLabels = {
    faithfulness: "Fa",
    relevance:    "Re",
    coherence:    "Co",
    groundedness: "Gr",
  };

  const hasGrounding = q.grounding && typeof q.grounding === "object";

  const groundingAvg = hasGrounding
    ? Math.round(
        groundingMetricKeys
          .map((k) => Number(q.grounding[k] ?? 0))
          .reduce((sum, v) => sum + v, 0) / groundingMetricKeys.length
      )
    : null;

  return (
    <div className="group relative bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      {/* Dossier colour accent bar */}
      <div className={`h-1 w-full ${m.colorBar}`} />

      <div className="p-5">

        {/* ── Row 1: Q{num} label + question text + copy button ── */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-start gap-2 flex-1 min-w-0">
            <span className={`shrink-0 text-xs font-bold mt-0.5 whitespace-nowrap ${m.colorQ}`}>
              Q{num}.
            </span>
            <p className="text-sm font-semibold text-slate-800 leading-snug">{q.question}</p>
          </div>
          <Button
            variant="ghost" size="sm"
            className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-opacity text-slate-400 hover:text-slate-700 shrink-0"
            onClick={() => onCopy(q)} title="Copy"
          >
            <Copy className="w-3.5 h-3.5" />
          </Button>
        </div>

        {/* ── Row 2: importance + dossier badge + therapy area (left) | grounding (right) ── */}
        <div className="flex items-center justify-between gap-3 flex-wrap mb-4">

          {/* Left side: importance, dossier name & therapy area badges */}
          <div className="flex items-center gap-2 flex-wrap">

            {/* Importance badge */}
            <span className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${is.badge}`}>
              <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${is.dot}`} />
              {q.importance}
            </span>

            {/* Dossier name badge */}
            {dossierName && (
              <span className={`flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full ${m.colorBadge}`}>
                <span className="shrink-0">{m.icon}</span>
                {dossierName}
              </span>
            )}

            {/* ── Therapy area badge ── */}
            {therapyArea && (
              <span className="flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-full bg-teal-50 text-teal-700 border border-teal-200">
                <Stethoscope className="w-3 h-3 shrink-0" />
                {therapyArea}
              </span>
            )}

          </div>

          {/* Right side: compact inline grounding widget */}
          {hasGrounding && (
            <div className="flex items-center gap-2.5 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 shrink-0">
              <div className="flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-slate-400 shrink-0" />
                <span className="text-xs font-bold uppercase tracking-wide text-slate-800">
                  Response Score
                </span>
              </div>
              <div className="w-px h-4 bg-slate-200 shrink-0" />
              <div className="flex items-center gap-3">
                {groundingMetricKeys.map((key) => {
                  const score = Math.max(0, Math.min(100, Number(q.grounding[key] ?? 0)));
                  return (
                    <div
                      key={key}
                      className="flex items-center gap-1"
                      title={`${key.charAt(0).toUpperCase() + key.slice(1)}: ${score}`}
                    >
                      <span className="text-xs text-slate-400">
                        {groundingMetricLabels[key]}
                      </span>
                      <span className={`text-xs font-bold tabular-nums ${groundingTextColor(score)}`}>
                        {score}
                      </span>
                    </div>
                  );
                })}
              </div>
              <div className="w-px h-4 bg-slate-200 shrink-0" />
              <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full border tabular-nums ${
                groundingAvg >= 80
                  ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                  : groundingAvg >= 60
                  ? "bg-amber-50 text-amber-600 border-amber-200"
                  : "bg-red-50 text-red-600 border-red-200"
              }`}>
                Avg {groundingAvg}
              </span>
            </div>
          )}
        </div>

        {/* ── Row 3: Suggested response box ── */}
        <div className={`rounded-lg border p-3.5 ${m.colorABg}`}>
          <div className="flex items-center gap-1.5 mb-2">
            <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${m.colorALabel}`} />
            <span className={`text-xs font-semibold uppercase tracking-wide ${m.colorALabel}`}>
              Suggested Response
            </span>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">{q.suggested_response}</p>
        </div>

      </div>
    </div>
  );
});

// ─── Dossier block (Fix #2 — memo) ───────────────────────────────────────────
const DossierBlock = memo(function DossierBlock({ dossier, offset, onCopy, therapyArea }) {
  const m  = getMeta(dossier.dossier_code);
  const qs = Array.isArray(dossier.predicted_questions) ? dossier.predicted_questions : [];
  return (
    <div
      className={`rounded-2xl border overflow-hidden ${m.colorBorder}`}
      data-testid={`dossier-section-${dossier.dossier_code}`}
    >
      <div className={`p-4 space-y-3 ${m.colorBg}`}>
        {qs.map((q, i) => (
          <QCard
            key={i}
            q={q}
            num={offset + i + 1}
            code={dossier.dossier_code}
            dossierName={dossier.dossier_name}
            therapyArea={therapyArea}
            onCopy={onCopy}
          />
        ))}
      </div>
    </div>
  );
});

// ─── Cycling thinking messages ────────────────────────────────────────────────
const THINKING_MESSAGES = [
  "Thinking...",
  "Analysing ruling patterns...",
  "Predicting ZIN questions...",
  "Reviewing dossier context...",
  "Formulating suggested responses...",
  "Evaluating grounding scores...",
  "Almost there...",
];

function useThinkingMessage(active) {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    if (!active) { setIndex(0); return; }
    const id = setInterval(() => {
      setIndex((prev) => (prev + 1) % THINKING_MESSAGES.length);
    }, 2000);
    return () => clearInterval(id);
  }, [active]);
  return THINKING_MESSAGES[index];
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function QAGenerator() {
  // ── Data ────────────────────────────────────────────────────────────────────
  const [rulings,               setRulings]               = useState([]);
  const [therapyAreas,          setTherapyAreas]          = useState([]);
  const [decisionOutcomes,      setDecisionOutcomes]      = useState([]);
  const [dossierCategories,     setDossierCategories]     = useState([]);

  // ── Filters ─────────────────────────────────────────────────────────────────
  const [searchQuery,               setSearchQuery]               = useState("");
  const [selectedTherapyAreas,      setSelectedTherapyAreas]      = useState([]);
  const [selectedOutcomes,          setSelectedOutcomes]          = useState([]);
  const [selectedDossierCategories, setSelectedDossierCategories] = useState([]);
  const [selectedYears,             setSelectedYears]             = useState([]);

  // ── YEAR FILTER: dropdown open/close state ───────────────────────────────────
  const [yearDropdownOpen, setYearDropdownOpen] = useState(false);

  // ── Generation ──────────────────────────────────────────────────────────────
  const [selectedRuling, setSelectedRuling] = useState(null);
  const [context,        setContext]        = useState("");
  const [dossiers,       setDossiers]       = useState([]);
  const [loading,        setLoading]        = useState(true);
  const [generating,     setGenerating]     = useState(false);
  const [rulingPage,     setRulingPage]     = useState(1);

  const thinkingMessage = useThinkingMessage(generating);

  // ── Fix #3: Debounced search ─────────────────────────────────────────────────
  const debouncedSearch = useDebounce(searchQuery, 300);

  // ── Derive therapy area from the currently selected ruling ──────────────────
  const selectedRulingTherapyArea = useMemo(() => {
    if (!selectedRuling) return null;
    const ruling = rulings.find((r) => r.id === selectedRuling);
    return ruling?.therapy_area ?? null;
  }, [selectedRuling, rulings]);

  // ── Fix #5: Optimised availableYears ────────────────────────────────────────
  const availableYears = useMemo(() => {
    const yearSet = rulings.reduce((acc, r) => {
      const year = (r?.decision_date || "").substring(0, 4);
      if (/^\d{4}$/.test(year)) acc.add(year);
      return acc;
    }, new Set());
    return [...yearSet].sort((a, b) => b.localeCompare(a));
  }, [rulings]);

  // ── YEAR FILTER: true when at least one ruling has a missing/invalid date ────
  const hasUnknownDateRulings = useMemo(() =>
    rulings.some((r) => {
      const date = r?.decision_date || "";
      return !date || date.length < 4 || !/^\d{4}$/.test(date.substring(0, 4));
    }),
  [rulings]);

  // ── Fix #3: Use debouncedSearch instead of searchQuery in filteredRulings ────
  const filteredRulings = useMemo(() => {
    let results = Array.isArray(rulings) ? rulings : [];
    const query = (debouncedSearch || "").toLowerCase().trim();
    if (query) {
      results = results.filter((r) =>
        (r?.title        || "").toLowerCase().includes(query) ||
        (r?.drug_name    || "").toLowerCase().includes(query) ||
        (r?.manufacturer || "").toLowerCase().includes(query) ||
        (r?.summary      || "").toLowerCase().includes(query)
      );
    }
    if (selectedTherapyAreas.length > 0)
      results = results.filter((r) => selectedTherapyAreas.includes(r?.therapy_area));
    if (selectedOutcomes.length > 0)
      results = results.filter((r) => selectedOutcomes.includes(r?.decision_outcome));
    if (selectedDossierCategories.length > 0)
      results = results.filter((r) => selectedDossierCategories.includes(r?.dossier_category));
    if (selectedYears.length > 0) {
      results = results.filter((r) => {
        const date = r?.decision_date || "";
        const year = date.length >= 4 ? date.substring(0, 4) : "";
        const isValidYear = /^\d{4}$/.test(year);
        if (isValidYear && selectedYears.includes(year)) return true;
        if (!isValidYear && selectedYears.includes("Unknown")) return true;
        return false;
      });
    }
    return results;
  }, [rulings, debouncedSearch, selectedTherapyAreas, selectedOutcomes, selectedDossierCategories, selectedYears]);

  // Reset to page 1 on any filter change
  useEffect(() => {
    setRulingPage(1);
  }, [debouncedSearch, selectedTherapyAreas, selectedOutcomes, selectedDossierCategories, selectedYears]);

  // ── Pagination ──────────────────────────────────────────────────────────────
  const totalRulingPages = Math.max(1, Math.ceil(filteredRulings.length / RULINGS_PAGE_SIZE));
  const paginatedRulings = useMemo(() => {
    const start = (rulingPage - 1) * RULINGS_PAGE_SIZE;
    return filteredRulings.slice(start, start + RULINGS_PAGE_SIZE);
  }, [filteredRulings, rulingPage]);

  const hasActiveFilters =
    Boolean(searchQuery)                ||
    selectedTherapyAreas.length > 0      ||
    selectedOutcomes.length > 0          ||
    selectedDossierCategories.length > 0 ||
    selectedYears.length > 0;

  const totalQCount = useMemo(
    () => dossiers.reduce((s, d) => s + (d.predicted_questions?.length || 0), 0),
    [dossiers]
  );

  // ── Fetch on mount ──────────────────────────────────────────────────────────
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [rulingsRes, taRes, doRes, dcRes] = await Promise.all([
          axios.get(`${API}/rulings`),
          axios.get(`${API}/therapy-areas`),
          axios.get(`${API}/decision-outcomes`),
          axios.get(`${API}/dossier-categories`),
        ]);
        setRulings(rulingsRes.data      || []);
        setTherapyAreas(taRes.data      || []);
        setDecisionOutcomes(doRes.data  || []);
        setDossierCategories(dcRes.data || []);
      } catch (err) {
        console.error("Failed to fetch data:", err);
        toast.error("Failed to load rulings");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // ── Fix #1: useCallback for all filter toggle helpers ────────────────────────
  const toggleTherapyArea = useCallback(
    (area) => setSelectedTherapyAreas((p) => p.includes(area) ? p.filter((a) => a !== area) : [...p, area]),
    []
  );
  const toggleOutcome = useCallback(
    (outcome) => setSelectedOutcomes((p) => p.includes(outcome) ? p.filter((o) => o !== outcome) : [...p, outcome]),
    []
  );
  const toggleDossierCategory = useCallback(
    (cat) => setSelectedDossierCategories((p) => p.includes(cat) ? p.filter((c) => c !== cat) : [...p, cat]),
    []
  );
  const toggleYear = useCallback(
    (year) => setSelectedYears((p) => p.includes(year) ? p.filter((y) => y !== year) : [...p, year]),
    []
  );
  const clearFilters = useCallback(() => {
    setSearchQuery("");
    setSelectedTherapyAreas([]);
    setSelectedOutcomes([]);
    setSelectedDossierCategories([]);
    setSelectedYears([]);
  }, []);
  const toggleRuling = useCallback(
    (id) => setSelectedRuling((p) => (p === id ? null : id)),
    []
  );

  // ── Fix #1: useCallback for generate, copyQ, exportAll ──────────────────────
  const generate = useCallback(async () => {
    if (!selectedRuling) { toast.warning("Please select a ruling"); return; }
    setGenerating(true);
    setDossiers([]);
    try {
      const { data } = await axios.post(`${API}/qa/generate`, {
        ruling_ids: [selectedRuling], context,
      });
      const arr = Array.isArray(data.dossiers)  ? data.dossiers
                : Array.isArray(data.questions) ? data.questions
                : [];
      setDossiers(arr);
      toast.success(arr.length > 0 ? `Loaded ${arr.length} dossiers` : "No dossiers returned");
    } catch (err) {
      console.error("generate error:", err);
      toast.error("Failed to generate questions");
    } finally {
      setGenerating(false);
    }
  }, [selectedRuling, context]);

  const copyQ = useCallback((q) => {
    const grounding = q.grounding
      ? `\n\nGrounding Scores:\n` +
        `  Faithfulness:  ${q.grounding.faithfulness ?? "N/A"}\n` +
        `  Relevance:     ${q.grounding.relevance ?? "N/A"}\n` +
        `  Coherence:     ${q.grounding.coherence ?? "N/A"}\n` +
        `  Groundedness:  ${q.grounding.groundedness ?? "N/A"}`
      : "";
    navigator.clipboard.writeText(
      `Q. ${q.question}\n\nImportance: ${q.importance}\n\nA. ${q.suggested_response}${grounding}`
    );
    toast.success("Copied");
  }, []);

  const exportAll = useCallback(() => {
    let n = 0;
    const txt = dossiers.map((d) => {
      const hdr  = `${"=".repeat(60)}\n${d.dossier_name}\n${"=".repeat(60)}`;
      const rows = (d.predicted_questions || []).map((q) => {
        n++;
        const grounding = q.grounding
          ? `\nGrounding — Faithfulness: ${q.grounding.faithfulness ?? "N/A"} | ` +
            `Relevance: ${q.grounding.relevance ?? "N/A"} | ` +
            `Coherence: ${q.grounding.coherence ?? "N/A"} | ` +
            `Groundedness: ${q.grounding.groundedness ?? "N/A"}`
          : "";
        return `[${n}] ${(q.importance || "").toUpperCase()}${grounding}\n\nQ. ${q.question}\n\nA. ${q.suggested_response}`;
      });
      return [hdr, ...rows].join("\n\n");
    }).join("\n\n");
    const a = Object.assign(document.createElement("a"), {
      href: URL.createObjectURL(new Blob([txt], { type: "text/plain" })),
      download: "hta-questions.txt",
    });
    a.click();
    toast.success("Exported");
  }, [dossiers]);

  const hasResults = dossiers.length > 0;

  // ── Loading skeleton ────────────────────────────────────────────────────────
  if (loading) return (
    <div className="flex min-h-screen" data-testid="qa-generator-loading">
      <div className="w-64 border-r border-slate-200 p-6">
        <Skeleton className="h-6 w-32 mb-6" />
        {[1,2,3,4,5].map((i) => <Skeleton key={i} className="h-5 w-full mb-3" />)}
      </div>
      <div className="w-80 border-r border-slate-200 p-4">
        <Skeleton className="h-8 w-full mb-4" />
        {[1,2,3,4].map((i) => <Skeleton key={i} className="h-20 w-full mb-3" />)}
      </div>
      <div className="flex-1 p-8">
        <Skeleton className="h-10 w-64 mb-8" />
        <Skeleton className="h-64 w-full" />
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen" data-testid="qa-generator-page">

      {/* ── COL 1: Filter sidebar ────────────────────────────────────────── */}
      <aside
        className="w-64 shrink-0 border-r border-slate-200 bg-white flex flex-col"
        data-testid="qa-filter-sidebar"
      >
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <Filter className="w-4 h-4" /> Filters
          </h2>
          {hasActiveFilters && (
            <Button
              variant="ghost" size="sm" onClick={clearFilters}
              className="text-slate-500 hover:text-slate-700 h-7 px-2"
              data-testid="qa-clear-filters-btn"
            >
              <X className="w-3.5 h-3.5 mr-1" /> Clear
            </Button>
          )}
        </div>

        <ScrollArea className="flex-1 px-5 py-4">

          {/* Therapy Area */}
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Therapy Area
            </h3>
            {therapyAreas.map((area) => (
              <div key={area} className="flex items-center gap-2 mb-2">
                <Checkbox
                  id={`qa-ta-${area}`}
                  checked={selectedTherapyAreas.includes(area)}
                  onCheckedChange={() => toggleTherapyArea(area)}
                />
                <Label htmlFor={`qa-ta-${area}`} className="text-sm cursor-pointer">
                  {area}
                </Label>
              </div>
            ))}
          </div>

          {/* Decision Outcome */}
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Decision Outcome
            </h3>
            {decisionOutcomes.map((outcome) => (
              <div key={outcome} className="flex items-center gap-2 mb-2">
                <Checkbox
                  id={`qa-do-${outcome}`}
                  checked={selectedOutcomes.includes(outcome)}
                  onCheckedChange={() => toggleOutcome(outcome)}
                />
                <Label htmlFor={`qa-do-${outcome}`} className="text-sm cursor-pointer">
                  {outcome}
                </Label>
              </div>
            ))}
          </div>

          {/* Dossier Category */}
          {/* <div className="mb-6">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Dossier Category
            </h3>
            {dossierCategories.map((cat) => (
              <div key={cat} className="flex items-center gap-2 mb-2">
                <Checkbox
                  id={`qa-dc-${cat}`}
                  checked={selectedDossierCategories.includes(cat)}
                  onCheckedChange={() => toggleDossierCategory(cat)}
                />
                <Label htmlFor={`qa-dc-${cat}`} className="text-sm cursor-pointer">
                  {cat}
                </Label>
              </div>
            ))}
          </div> */}

          {/* ── YEAR FILTER ───────────────────────────────────────────────── */}
          {(availableYears.length > 0 || hasUnknownDateRulings) && (
            <div className="mb-6">
              <button
                type="button"
                onClick={() => setYearDropdownOpen((prev) => !prev)}
                className="w-full flex items-center justify-between
                  text-xs font-semibold text-slate-500 uppercase tracking-wider
                  cursor-pointer select-none focus:outline-none
                  hover:text-slate-700 transition-colors mb-1"
                aria-expanded={yearDropdownOpen}
                aria-controls="qa-year-filter-dropdown"
                data-testid="qa-year-filter-toggle"
              >
                <span className="flex items-center gap-2">
                  YEAR
                  {selectedYears.length > 0 && (
                    <span className="inline-flex items-center justify-center h-4 min-w-[1rem] px-1 rounded-full bg-sky-600 text-white text-[10px] font-semibold">
                      {selectedYears.length}
                    </span>
                  )}
                </span>
                <ChevronRight
                  className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${yearDropdownOpen ? "rotate-90" : ""}`}
                />
              </button>

              {yearDropdownOpen && (
                <div
                  id="qa-year-filter-dropdown"
                  className="mt-1 border border-slate-200 rounded-md bg-white shadow-sm overflow-hidden"
                  data-testid="qa-year-filter-dropdown"
                >
                  <div className="max-h-48 overflow-y-auto py-1">
                    {availableYears.map((year) => (
                      <label
                        key={year}
                        className="flex items-center gap-2 px-3 py-1.5 cursor-pointer hover:bg-slate-50 transition-colors"
                        data-testid={`qa-year-filter-${year}`}
                      >
                        <Checkbox
                          checked={selectedYears.includes(year)}
                          onCheckedChange={() => toggleYear(year)}
                        />
                        <span className="text-sm text-slate-700">{year}</span>
                      </label>
                    ))}
                    {hasUnknownDateRulings && (
                      <label
                        className="flex items-center gap-2 px-3 py-1.5 cursor-pointer hover:bg-slate-50 transition-colors"
                        data-testid="qa-year-filter-unknown"
                      >
                        <Checkbox
                          checked={selectedYears.includes("Unknown")}
                          onCheckedChange={() => toggleYear("Unknown")}
                        />
                        <span className="text-sm text-slate-400 italic">Unknown date</span>
                      </label>
                    )}
                  </div>
                  {selectedYears.length > 0 && (
                    <div className="border-t border-slate-100 px-3 py-1.5">
                      <button
                        type="button"
                        onClick={() => setSelectedYears([])}
                        className="text-xs text-sky-600 hover:text-sky-800 transition-colors focus:outline-none"
                        data-testid="qa-year-filter-clear"
                      >
                        Clear year selection
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

        </ScrollArea>
      </aside>

      {/* ── COL 2: Ruling selection panel ───────────────────────────────── */}
      <aside
        className="w-80 shrink-0 border-r border-slate-200 bg-white flex flex-col"
        data-testid="qa-ruling-panel"
      >
        <div className="p-4 border-b border-slate-200">
          <h2 className="text-sm font-semibold text-slate-900 font-heading mb-3">
            Select Reference Ruling
          </h2>
          <div className="relative">
            <SearchIcon className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <Input
              type="text"
              placeholder="Search rulings..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 h-8 text-sm"
              data-testid="qa-ruling-search-input"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Active filter badges */}
        {hasActiveFilters && (
          <div className="px-4 pt-2 pb-1 flex flex-wrap gap-1.5 border-b border-slate-100">
            {selectedTherapyAreas.map((area) => (
              <Badge key={area} variant="secondary"
                className="text-xs h-5 gap-1 pr-1 cursor-pointer"
                onClick={() => toggleTherapyArea(area)}>
                {area} <X className="w-2.5 h-2.5" />
              </Badge>
            ))}
            {selectedOutcomes.map((outcome) => (
              <Badge key={outcome} variant="secondary"
                className="text-xs h-5 gap-1 pr-1 cursor-pointer"
                onClick={() => toggleOutcome(outcome)}>
                {outcome} <X className="w-2.5 h-2.5" />
              </Badge>
            ))}
            {selectedDossierCategories.map((cat) => (
              <Badge key={cat} variant="secondary"
                className="text-xs h-5 gap-1 pr-1 cursor-pointer"
                onClick={() => toggleDossierCategory(cat)}>
                {cat} <X className="w-2.5 h-2.5" />
              </Badge>
            ))}
            {selectedYears.map((year) => (
              <Badge key={year} variant="secondary"
                className="text-xs h-5 gap-1 pr-1 cursor-pointer"
                onClick={() => toggleYear(year)}>
                {year === "Unknown" ? "Unknown date" : year}
                <X className="w-2.5 h-2.5" />
              </Badge>
            ))}
          </div>
        )}

        {/* Count */}
        <div className="px-4 pt-2 pb-1 flex items-center justify-between">
          <p className="text-xs text-slate-500">
            <span className="font-semibold text-slate-700">{filteredRulings.length}</span>{" "}
            {hasActiveFilters ? "matching" : "total"} rulings
          </p>
          {filteredRulings.length > 0 && (
            <p className="text-xs text-slate-400">
              Showing{" "}
              <span className="font-medium text-slate-600">
                {(rulingPage - 1) * RULINGS_PAGE_SIZE + 1}–
                {Math.min(rulingPage * RULINGS_PAGE_SIZE, filteredRulings.length)}
              </span>
            </p>
          )}
        </div>

        {/* Ruling cards */}
        <ScrollArea className="flex-1 p-4">
          {filteredRulings.length === 0 ? (
            <div className="text-center py-8" data-testid="qa-no-rulings">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-slate-500 font-medium">No rulings match</p>
              <p className="text-xs text-slate-400 mt-1">
                Try adjusting your filters or search query
              </p>
              <Button variant="outline" size="sm" onClick={clearFilters} className="mt-3 text-xs">
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {paginatedRulings.map((ruling) => {
                const sel = selectedRuling === ruling.id;
                return (
                  <Card
                    key={ruling.id}
                    onClick={() => toggleRuling(ruling.id)}
                    className={`cursor-pointer transition-all ${
                      sel
                        ? "border-sky-500 bg-sky-50 shadow-sm"
                        : "border-slate-200 hover:border-slate-300"
                    }`}
                    data-testid={`select-ruling-${ruling.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className={`mt-1 w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center transition-all ${
                          sel ? "border-sky-500 bg-sky-500" : "border-slate-300 bg-white"
                        }`}>
                          {sel && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`font-medium text-sm line-clamp-2 ${
                            sel ? "text-sky-900" : "text-slate-900"
                          }`}>
                            {ruling.title}
                          </p>
                          <div className="flex items-center gap-2 mt-2 flex-wrap">
                            <Badge variant="outline" className="text-xs">
                              {ruling.therapy_area}
                            </Badge>
                            <Badge variant="outline" className={`text-xs ${
                              ruling.decision_outcome === "Positive" ? "badge-positive"
                              : ruling.decision_outcome === "Negative" ? "badge-negative"
                              : "badge-conditional"
                            }`}>
                              {ruling.decision_outcome}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </ScrollArea>

        <RulingPaginationControls
          currentPage={rulingPage}
          totalPages={totalRulingPages}
          onPageChange={setRulingPage}
        />

        <div className="p-4 border-t border-slate-200 bg-slate-50">
          {selectedRuling ? (
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm text-slate-600">
                <span className="font-semibold text-sky-700">1</span> ruling selected
              </p>
              <Button
                variant="ghost" size="sm"
                onClick={() => setSelectedRuling(null)}
                className="text-xs text-slate-400 hover:text-slate-600 h-6 px-2"
                data-testid="clear-ruling-btn"
              >
                Clear
              </Button>
            </div>
          ) : (
            <p className="text-sm text-slate-400 italic">No ruling selected</p>
          )}
        </div>
      </aside>

      {/* ── COL 3: Main Q&A content ──────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="page-header">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-sky-100 rounded-xl flex items-center justify-center">
                <BrainCircuit className="w-5 h-5 text-sky-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900 font-heading">Q&amp;A Generator</h1>
                <p className="text-slate-500">
                  Predict questions ZIN may ask during your submission review
                </p>
              </div>
            </div>
            {hasResults && (
              <Button variant="outline" onClick={exportAll} data-testid="export-all-btn">
                <Download className="w-4 h-4 mr-2" /> Export All
              </Button>
            )}
          </div>
        </header>

        <div className="flex-1 p-8 bg-slate-50 dot-pattern overflow-auto">

          {/* Context card */}
          <Card className="mb-6 border-slate-200" data-testid="context-input-card">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg font-semibold text-slate-900 font-heading">
                Additional Context (Optional)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Describe your drug, indication, or specific concerns you want addressed..."
                value={context}
                onChange={(e) => setContext(e.target.value)}
                rows={3}
                className="resize-none"
                data-testid="context-textarea"
              />
              <div className="flex items-center justify-between mt-4">
                <p className="text-xs text-slate-500">
                  The AI will use the selected ruling and your context to generate relevant questions
                </p>
                <Button
                  onClick={generate}
                  disabled={generating || !selectedRuling}
                  className="bg-sky-600 hover:bg-sky-700 min-w-[240px] justify-center"
                  data-testid="generate-qa-btn"
                >
                  {generating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin shrink-0" />
                      <span>{thinkingMessage}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Questions
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results area */}
          {generating ? (
            <div
              className="flex flex-col items-center justify-center py-20 bg-white rounded-xl border border-slate-200"
              data-testid="qa-generating-state"
            >
              <div className="relative mb-6">
                <BrainCircuit className="w-14 h-14 text-sky-300" />
                <Loader2 className="w-6 h-6 text-sky-600 animate-spin absolute -bottom-1 -right-1" />
              </div>
              <h3 className="text-lg font-semibold text-slate-800 mb-1">{thinkingMessage}</h3>
              <p className="text-sm text-slate-400 max-w-xs text-center">
                Analysing the selected ruling and generating predicted ZIN questions for each dossier type.
              </p>
              <div className="flex gap-1.5 mt-5">
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    className="w-2 h-2 rounded-full bg-sky-400 animate-bounce"
                    style={{ animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </div>
            </div>
          ) : !hasResults ? (
            <div
              className="empty-state bg-white rounded-xl border border-slate-200"
              data-testid="qa-empty-state"
            >
              <BrainCircuit className="empty-state-icon" />
              <h3 className="empty-state-title">No Questions Generated Yet</h3>
              <p className="empty-state-description">
                Select a reference ruling from the left panel and click
                &quot;Generate Questions&quot; to predict what ZIN may ask during your submission review.
              </p>
            </div>
          ) : (
            <div data-testid="qa-results">
              <div className="flex items-center gap-2 mb-5">
                <Lightbulb className="w-4 h-4 text-sky-600" />
                <h3 className="text-base font-semibold text-slate-900 font-heading">
                  Predicted Questions ({totalQCount}) across {dossiers.length}{" "}
                  {dossiers.length === 1 ? "dossier" : "dossiers"}
                </h3>
              </div>
              <div className="space-y-6">
                {dossiers.map((dossier, di) => {
                  const offset = dossiers
                    .slice(0, di)
                    .reduce((s, d) => s + (d.predicted_questions?.length || 0), 0);
                  return (
                    <DossierBlock
                      key={dossier.dossier_code ?? di}
                      dossier={dossier}
                      offset={offset}
                      onCopy={copyQ}
                      therapyArea={selectedRulingTherapyArea}
                    />
                  );
                })}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}