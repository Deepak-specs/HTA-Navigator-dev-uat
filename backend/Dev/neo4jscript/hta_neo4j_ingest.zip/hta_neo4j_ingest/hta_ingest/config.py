"""
config.py
=========
All settings come from environment variables (or a local .env file).
Nothing secret lives in code or in config.toml.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # python-dotenv is optional
    pass

# Bump these when the code or prompts change; `--resummarise` / `--retranslate`
# then reprocess only documents produced by an older version.
PIPELINE_VERSION = "ingest-2026.09.1"
TRANSLATION_VERSION = "translate-v1"
PROMPT_VERSION = "summary-v1"


def _env(name: str, default: str | None = None) -> str | None:
    v = os.environ.get(name)
    return v if v not in (None, "") else default


@dataclass(frozen=True)
class Settings:
    # Neo4j
    neo4j_uri: str | None
    neo4j_user: str | None
    neo4j_password: str | None
    neo4j_database: str
    # LLM (Bedrock through the AZ AI gateway -- same client pattern as function_app.py)
    bedrock_gateway_url: str | None
    bedrock_api_key: str | None
    bedrock_region: str
    bedrock_model: str | None
    bedrock_access_key_id: str | None
    # Source (zin_sinks)
    sink: str
    root: str
    account: str
    pdf_container: str
    json_container: str
    # Tuning
    concurrency: int
    translate_chunk_chars: int
    max_summary_chars: int

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            neo4j_uri=_env("NEO4J_URI"),
            neo4j_user=_env("NEO4J_USER"),
            neo4j_password=_env("NEO4J_PASSWORD"),
            neo4j_database=_env("NEO4J_DATABASE", "neo4j"),
            bedrock_gateway_url=_env("BEDROCK_GATEWAY_URL"),
            bedrock_api_key=_env("BEDROCK_API_KEY"),
            bedrock_region=_env("BEDROCK_REGION", "us-east-1"),
            bedrock_model=_env("BEDROCK_MODEL"),
            bedrock_access_key_id=_env("BEDROCK_ACCESS_KEY_ID"),
            sink=_env("ZIN_SINK", "azure"),
            root=_env("ZIN_ROOT", "./zin_data"),
            account=_env("AZURE_STORAGE_ACCOUNT", "nlhtanavigatorukspocsa"),
            pdf_container=_env("ZIN_PDF_CONTAINER", "test-1709"),
            json_container=_env("ZIN_JSON_CONTAINER", "jsonoutput-1709"),
            concurrency=int(_env("INGEST_CONCURRENCY", "2")),
            translate_chunk_chars=int(_env("TRANSLATE_CHUNK_CHARS", "9000")),
            max_summary_chars=int(_env("MAX_SUMMARY_CHARS", "300000")),
        )

    def with_overrides(self, **kw) -> "Settings":
        data = {**self.__dict__, **{k: v for k, v in kw.items() if v is not None}}
        return Settings(**data)

    def require(self, *names: str) -> None:
        missing = [n for n in names if not getattr(self, n)]
        if missing:
            env_names = ", ".join(n.upper() for n in missing)
            raise SystemExit(f"Missing required settings: {env_names} (set them in .env)")
